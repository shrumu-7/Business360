
"use strict";

// Core UI helpers — kept here so every navigation/modal/toast action is always available.
const esc = v => String(v ?? "").replace(/[&<>\"]/g, m => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[m]));
function toast(msg){ const el=document.getElementById("toast"); if(!el)return; el.textContent=String(msg||""); el.classList.add("show"); clearTimeout(window.__toastTimer); window.__toastTimer=setTimeout(()=>el.classList.remove("show"),2600); }
function modal(html){ const back=document.getElementById("modalback"), box=document.getElementById("modal"); if(!back||!box)return; box.innerHTML=html||""; back.classList.add("show"); }
function closeModal(){ const back=document.getElementById("modalback"); if(back)back.classList.remove("show"); }

const KEY="business360_complete_v3";
const BACKUP_KEY="business360_safety_backups_v1";
const DATA_SCHEMA_VERSION=5;
const IDB_NAME="business360_data_v1", IDB_STORE="state";
function migrateData(x){
  if(!x||typeof x!=="object") return clone(initial);
  x.settings={...initial.settings,...(x.settings||{})};
  x.settings.dashboardCardColors={...initial.settings.dashboardCardColors,...(x.settings.dashboardCardColors||{})};
  x.settings.dashboardOrder=Array.isArray(x.settings.dashboardOrder)&&x.settings.dashboardOrder.length?x.settings.dashboardOrder.slice():[...initial.settings.dashboardOrder];
  for(const k of ["products","customers","suppliers","sales","purchases","expenses","payments","returns","stockMoves"]) if(!Array.isArray(x[k])) x[k]=[];
  x.counters={...initial.counters,...(x.counters||{})};
  if(!x._meta||typeof x._meta!=="object") x._meta={};
  x._meta.schemaVersion=DATA_SCHEMA_VERSION;
  return x;
}
function getSafetyBackups(){try{return JSON.parse(localStorage.getItem(BACKUP_KEY)||"[]")}catch(_){return []}}
function saveSafetyBackups(a){try{localStorage.setItem(BACKUP_KEY,JSON.stringify(a.slice(0,15)))}catch(_){}}
function makeSafetyBackup(reason="নিরাপত্তা Backup"){
  const a=getSafetyBackups();
  a.unshift({id:uid("BK"),reason,date:new Date().toISOString(),db:clone(db)});
  saveSafetyBackups(a);
  return a[0].id;
}
function manualProductBackup(id){const p=db.products.find(x=>x.id===id);if(!p)return;makeSafetyBackup(`পণ্য Backup: ${p.name}`);toast("এই পণ্যের বর্তমান অবস্থার Backup নেওয়া হয়েছে")}
function manualPartyBackup(type,id){const arr=type==="customer"?db.customers:db.suppliers,p=arr.find(x=>x.id===id);if(!p)return;makeSafetyBackup(`${type==="customer"?"Customer":"Supplier"} Backup: ${p.name}`);toast("এই Party-এর বর্তমান অবস্থার Backup নেওয়া হয়েছে")}
function openSafetyBackups(){
  const a=getSafetyBackups();
  modal(`<div class="modalhead"><div><h2>💾 Safety Backup</h2><div class="sub">Delete/Reset-এর আগে নেওয়া Backup থেকে পুরো হিসাব আগের অবস্থায় ফিরিয়ে আনতে পারবেন।</div></div><button class="close" onclick="closeModal()">✕</button></div>${a.length?a.map((b,i)=>`<div class="backup-row"><div><b>${esc(b.reason)}</b><div class="sub">${new Date(b.date).toLocaleString("bn-BD")}</div></div><div class="toolbar"><button class="btn sm" onclick="restoreSafetyBackup(${i})">Restore</button><button class="btn sm danger-outline" onclick="deleteSafetyBackup(${i})">Delete</button></div></div>`).join(""):`<div class="empty">এখনও কোনো Safety Backup নেই।</div>`}<div class="notice" style="margin-top:12px">Backup আলাদা storage-এ রাখা হয়, তাই পণ্য/Party delete বা সব হিসাব reset করার পরও Restore করা যাবে।</div>`);
}
function restoreSafetyBackup(index){const a=getSafetyBackups(),b=a[index];if(!b)return;if(!confirm(`এই Backup Restore করলে বর্তমান হিসাব Backup-এর সময়কার অবস্থায় ফিরে যাবে। Restore করবেন?\n\n${b.reason}`))return;makeSafetyBackup("Restore-এর আগের বর্তমান অবস্থা");db=migrateData(clone(b.db));save();closeModal();applyTheme(db.settings.theme||"purple",true);applyAppBackground(db.settings.appBg||"blueWhite",true);applyProductBg(db.settings.productBg||"auto",true);applyDashboardStyle();applyLogo(db.settings.logo||"");render("dashboard");toast("Safety Backup Restore হয়েছে")}
function deleteSafetyBackup(index){const a=getSafetyBackups();if(!a[index])return;if(confirm("এই Backup মুছে ফেলবেন?")){a.splice(index,1);saveSafetyBackups(a);openSafetyBackups()}}
const money=n=>"৳ "+Number(n||0).toLocaleString("bn-BD",{minimumFractionDigits:2,maximumFractionDigits:2});
const num=n=>Number(n||0);
const uid=(p="ID")=>p+"-"+Date.now().toString(36)+"-"+Math.random().toString(36).slice(2,7);
function categoryList(){const seen=new Set(),out=[];for(const p of db.products||[]){const c=String(p.category||"").trim();if(!c)continue;const k=c.toLocaleLowerCase();if(!seen.has(k)){seen.add(k);out.push(c)}}return out.sort((a,b)=>a.localeCompare(b,"bn",{sensitivity:"base"}))}
function categoryDatalist(id="categorySuggestions"){return `<datalist id="${id}">${categoryList().map(c=>`<option value="${esc(c)}"></option>`).join("")}</datalist>`}
let savingSale=false,savingPurchase=false,savingProduct=false;
const today=()=>new Date().toISOString().slice(0,10);
const clone=o=>JSON.parse(JSON.stringify(o));
const initial={
 settings:{shop:"আমার দোকান",address:"",phone:"",currency:"৳",invoicePrefix:"INV",lowStock:5,receiptWidth:"80mm",theme:"purple",appBg:"blueWhite",productBg:"auto",dashboardBg:"midnight",dashboardCardBg:"gradient",dashboardBorder:"glow",dashboardCardColors:{income:"emerald",expense:"ruby",products:"blue",parties:"pink",sales:"orange",purchase:"turquoise",dues:"purple",debt:"indigo",stock:"cyan",stockValue:"gold",profit:"emerald"},buttonTheme:"neon",panelBg:"obsidian",dashboardOrder:["income","expense","products","parties","sales","purchase","dues","stock","stockValue","profit"],logo:"branding/business360_logo.png",logoRemoved:false,securityMode:"none",pinHash:"",patternHash:""},
 products:[],customers:[],suppliers:[],sales:[],purchases:[],expenses:[],payments:[],returns:[],stockMoves:[],
 counters:{sale:1001,purchase:2001,return:3001}
};
let db=load(), saleCart=[], purchaseCart=[];
function load(){try{const x=JSON.parse(localStorage.getItem(KEY));return migrateData(x||initial)}catch(e){return clone(initial)}}
function idbOpen(){return new Promise((resolve,reject)=>{if(!window.indexedDB)return resolve(null);const r=indexedDB.open(IDB_NAME,1);r.onupgradeneeded=()=>{if(!r.result.objectStoreNames.contains(IDB_STORE))r.result.createObjectStore(IDB_STORE)};r.onsuccess=()=>resolve(r.result);r.onerror=()=>resolve(null)})}
function idbGet(){return idbOpen().then(dbx=>new Promise(resolve=>{if(!dbx)return resolve(null);const tx=dbx.transaction(IDB_STORE,"readonly"),q=tx.objectStore(IDB_STORE).get("db");q.onsuccess=()=>resolve(q.result||null);q.onerror=()=>resolve(null)}))}
function idbPut(value){return idbOpen().then(dbx=>new Promise(resolve=>{if(!dbx)return resolve(false);const tx=dbx.transaction(IDB_STORE,"readwrite");tx.objectStore(IDB_STORE).put(value,"db");tx.oncomplete=()=>{dbx.close();resolve(true)};tx.onerror=()=>{dbx.close();resolve(false)}}))}
async function initDataStore(){
  const local=load(); const remote=await idbGet();
  const ls=Number(local?._meta?.updatedAt||0), rs=Number(remote?._meta?.updatedAt||0);
  if(remote && rs>ls) db=migrateData(remote); else {db=local; if(ls) await idbPut(db)}
  try{localStorage.setItem(KEY,JSON.stringify(db))}catch(_){}
}
let cloudTimer=null;
let cloudBusy=false;
function save(){
  try{db._meta={...(db._meta||{}),schemaVersion:DATA_SCHEMA_VERSION,updatedAt:Date.now()};localStorage.setItem(KEY,JSON.stringify(db)); idbPut(db).catch(()=>{});}
  catch(e){toast("ডেটা সেভ করতে সমস্যা হয়েছে—Backup নিন");}
  queueCloudSync();
}
function queueCloudSync(){
  if(!cloudState.connected)return;
  clearTimeout(cloudTimer);
  cloudTimer=setTimeout(()=>cloudUpload(false),1500);
}
const cloudState={connected:false,token:null,clientId:localStorage.getItem("business360_google_client_id")||"",fileId:null,lastSync:null};
function cloudStatus(msg,ok=false){const el=document.getElementById("cloudStatus");if(el){el.textContent=msg;el.className="sub "+(ok?"pill ok":"");}}
function saveClientId(){const v=(document.getElementById("googleClientId")?.value||"").trim();if(!v){toast("Google Client ID দিন");return}localStorage.setItem("business360_google_client_id",v);cloudState.clientId=v;toast("Client ID সেভ হয়েছে");cloudConnect();}
function cloudConnect(){
  if(!cloudState.clientId){toast("Settings থেকে Google Client ID দিন");return}
  if(!window.google?.accounts?.oauth2){toast("Google Sign-in লোড হচ্ছে, কয়েক সেকেন্ড পর আবার চেষ্টা করুন");return}
  const client=google.accounts.oauth2.initTokenClient({client_id:cloudState.clientId,scope:"https://www.googleapis.com/auth/drive.appdata",callback:async(resp)=>{
    if(resp.error){toast("Google Drive অনুমতি নেওয়া যায়নি");return}
    cloudState.token=resp.access_token;cloudState.connected=true;
    cloudStatus("Google Drive সংযুক্ত ✓",true);
    await cloudDownload(true);
  }});
  client.requestAccessToken({prompt:"consent"});
}
async function driveFetch(url,opts={}){
  const r=await fetch(url,{...opts,headers:{Authorization:"Bearer "+cloudState.token,...(opts.headers||{})}});
  if(!r.ok)throw new Error(await r.text());
  return r;
}
async function cloudDownload(silent=false){
  if(!cloudState.token)return;
  try{
    const q=encodeURIComponent("name='business360-cloud.json' and 'appDataFolder' in parents and trashed=false");
    const r=await driveFetch("https://www.googleapis.com/drive/v3/files?q="+q+"&spaces=appDataFolder&fields=files(id,name,modifiedTime,size)");
    const j=await r.json();const f=(j.files||[]).sort((a,b)=>new Date(b.modifiedTime)-new Date(a.modifiedTime))[0];
    if(!f){cloudStatus("Drive সংযুক্ত — প্রথম Backup এখনো হয়নি",true);await cloudUpload(true);return}
    cloudState.fileId=f.id;
    const rr=await driveFetch("https://www.googleapis.com/drive/v3/files/"+f.id+"?alt=media");
    const remote=await rr.json();
    const localStamp=Number(localStorage.getItem(KEY+"_updated")||0), remoteStamp=Number(remote._meta?.updatedAt || new Date(f.modifiedTime).getTime());
    if(remoteStamp>localStamp && confirm("Google Drive-এ নতুন হিসাব পাওয়া গেছে। সেটি এই মোবাইলে Restore করবেন?")){
      db={...remote,settings:{...initial.settings,...(remote.settings||{})}};
      db=migrateData(remote);localStorage.setItem(KEY,JSON.stringify(db));idbPut(db);localStorage.setItem(KEY+"_updated",String(Date.now()));
      applyTheme(db.settings.theme||"purple");applyProductBg(db.settings.productBg||"auto");applyDashboardStyle();applyLogo(db.settings.logo||"");render("dashboard");
      toast("Google Drive থেকে হিসাব Restore হয়েছে");
    }
    cloudState.lastSync=new Date();cloudStatus("সর্বশেষ Sync: "+cloudState.lastSync.toLocaleTimeString("bn-BD"),true);
  }catch(e){cloudStatus("Drive Sync ব্যর্থ — ইন্টারনেট/Client ID পরীক্ষা করুন");if(!silent)toast("Google Drive থেকে ডেটা আনা যায়নি")}
}
async function cloudUpload(silent=false){
  if(!cloudState.token||cloudBusy)return;cloudBusy=true;
  try{
    const payload=JSON.parse(JSON.stringify(db));payload._meta={app:"business360",version:47,updatedAt:Date.now()};
    const body=JSON.stringify(payload);
    const metadata=cloudState.fileId?{name:"business360-cloud.json"}:{name:"business360-cloud.json",parents:["appDataFolder"]};
    const url=cloudState.fileId?"https://www.googleapis.com/upload/drive/v3/files/"+cloudState.fileId+"?uploadType=multipart":"https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart";
    const boundary="business360_boundary_"+Date.now();
    const multipart="--"+boundary+"\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n"+JSON.stringify(metadata)+"\r\n--"+boundary+"\r\nContent-Type: application/json\r\n\r\n"+body+"\r\n--"+boundary+"--";
    const r=await driveFetch(url,{method:cloudState.fileId?"PATCH":"POST",headers:{"Content-Type":"multipart/related; boundary="+boundary},body:multipart});
    const out=await r.json();if(out.id)cloudState.fileId=out.id;
    localStorage.setItem(KEY+"_updated",String(payload._meta.updatedAt));cloudState.lastSync=new Date();cloudStatus("সর্বশেষ Sync: "+cloudState.lastSync.toLocaleTimeString("bn-BD"),true);
  }catch(e){if(!silent)toast("Google Drive Backup ব্যর্থ হয়েছে")}finally{cloudBusy=false}
}
function cloudDisconnect(){cloudState.connected=false;cloudState.token=null;cloudState.fileId=null;cloudStatus("Google Drive সংযুক্ত নয়");toast("Google Drive সংযোগ বন্ধ হয়েছে");}

function applyDashboardStyle(){
 const bgMap={auto:"var(--bg)",midnight:"#070a18",black:"#0b0d12",charcoal:"#11151c",purple:"#17102f",blue:"#071a33",green:"#071f1a",wine:"#260914",royal:"#0d1233",aurora:"#071b20",leaf:"#0d3b20",sunrise:"#4a2508",ocean:"#062c3a",auroraGlow:"#20104a",sunsetGlow:"#4a1720",paper:"#2b2923",gold:"#3a2605"};
 const cardMap={auto:"var(--card)",gradient:"linear-gradient(135deg,#11152b,#17122f)",black:"#0c0f16",charcoal:"#141923",navy:"#0b1730",plum:"#21102f"};
 const borderMap={soft:"#ffffff28",strong:"#ffffff66",glow:"#8b5cf6"};
 const root=document.documentElement, st=db?.settings||{};
 root.style.setProperty("--dash-bg",bgMap[st.dashboardBg]||bgMap.midnight);
 root.style.setProperty("--dash-card",cardMap[st.dashboardCardBg]||cardMap.gradient);
 root.style.setProperty("--dash-border-color",borderMap[st.dashboardBorder]||borderMap.glow);
 root.style.setProperty("--dash-card-text","#f8f7ff");
 root.style.setProperty("--dash-card-muted","#c8c4d9");
 root.style.setProperty("--dash-radius",st.dashboardBorder==="strong"?"24px":"20px");
 root.dataset.dashboardbg=st.dashboardBg||"midnight";
 root.dataset.dashboardcardbg=st.dashboardCardBg||"gradient";
 root.dataset.dashboardborder=st.dashboardBorder||"glow";
 root.dataset.buttontheme=st.buttonTheme||"neon"; applyPanelBg(st.panelBg||"auto",true);
 const colors={ruby:"#ff2d75",indigo:"#3b82ff",blue:"#1677ff",pink:"#ff1493",orange:"#ff8a00",teal:"#00d4b8",violet:"#8b5cf6",emerald:"#00c98b",cyan:"#00c8ff",gold:"#f5b400",purple:"#a855f7",red:"#ef4444",magenta:"#e00078",turquoise:"#00c9b7"};
 const cc=st.dashboardCardColors||{};
 const defaults={income:"emerald",expense:"ruby",products:"blue",parties:"pink",sales:"orange",purchase:"turquoise",dues:"purple",debt:"indigo",stock:"cyan",stockValue:"gold",profit:"emerald"};
 Object.keys(defaults).forEach(k=>root.style.setProperty("--dc-"+k,colors[cc[k]]||colors[defaults[k]]));
 Object.keys(cc).forEach(k=>root.style.setProperty("--dc-"+k,colors[cc[k]]||colors.violet));
}
function setDashboardCardColor(key,color){
 const allowed={income:1,expense:1,products:1,parties:1,sales:1,purchase:1,dues:1,debt:1,stock:1,stockValue:1,profit:1};
 const colors={ruby:1,indigo:1,blue:1,pink:1,orange:1,teal:1,violet:1,emerald:1,cyan:1,gold:1,purple:1,red:1,magenta:1,turquoise:1};
 if(!allowed[key]||!colors[color])return;
 db.settings.dashboardCardColors={...(db.settings.dashboardCardColors||{}),[key]:color};
 save(); applyDashboardStyle(); settingsPage();
 toast("Dashboard card-এর রং সেভ হয়েছে");
}

function applyButtonTheme(v, silent=false){
 const allowed=["neon","jewel","aurora","mono"]; if(!allowed.includes(v))v="neon";
 if(db&&db.settings){db.settings.buttonTheme=v;try{localStorage.setItem(KEY,JSON.stringify(db));}catch(_){}idbPut(db).catch(()=>{});}
 document.documentElement.dataset.buttontheme=v;
 if(!silent)toast("সব বাটনের থিম: "+({neon:"Premium Neon",jewel:"Jewel",aurora:"Aurora",mono:"Midnight"}[v]||v));
}
function applyPanelBg(v, silent=false){
 const allowed=['auto','obsidian','navy','plum','wine','emerald','royal','gold'];if(!allowed.includes(v))v='auto';
 const maps={auto:['#111522','#f7f8ff','#ffffff2b'],obsidian:['#0b0d12','#f7f7fb','#ffffff2b'],navy:['#0b1730','#f4f7ff','#ffffff2b'],plum:['#21102f','#faf5ff','#ffffff2b'],wine:['#300d1b','#fff4f7','#ffffff2b'],emerald:['#073b2f','#f0fff9','#ffffff2b'],royal:['#101d4a','#f2f6ff','#ffffff2b'],gold:['#3a2605','#fff9e8','#ffffff2b']};
 const m=maps[v],root=document.documentElement;root.style.setProperty('--panel-bg',m[0]);root.style.setProperty('--panel-text',m[1]);root.style.setProperty('--panel-line',m[2]);root.dataset.panelbg=v;
 if(db&&db.settings){db.settings.panelBg=v;try{localStorage.setItem(KEY,JSON.stringify(db));}catch(_){}idbPut(db).catch(()=>{});}
 if(!silent)toast('হিসাব বক্সের Background সেভ হয়েছে');
}
function applyProductBg(v, silent=false){
 const allowed=["auto","white","gray","black","purple","blue","green"]; if(!allowed.includes(v))v="auto";
 const maps={auto:["var(--card)","var(--card)","var(--card)","var(--text)"],white:["#ffffff","#ffffff","#ffffff","#222222"],gray:["#eef0f2","#ffffff","#ffffff","#25262a"],black:["#111214","#17181b","#151619","#f5f5f5"],purple:["#241d3d","#2b2348","#30284e","#f7f3ff"],blue:["#10243a","#162f4c","#193756","#f0f7ff"],green:["#102d24","#153b30","#194638","#effff8"]};
 const m=maps[v]; const root=document.documentElement;
 root.style.setProperty("--product-bg",m[0]);root.style.setProperty("--product-inner",m[1]);root.style.setProperty("--product-input",m[2]);root.style.setProperty("--product-text",m[3]);root.style.setProperty("--product-line",v==="auto"?"var(--line)":"#ffffff33");root.dataset.productbg=v;
 if(db&&db.settings){db.settings.productBg=v; try{localStorage.setItem(KEY,JSON.stringify(db));}catch(_){} idbPut(db).catch(()=>{});}
 if(!silent)toast("পণ্য অংশের Background: "+v);
}
function applyAppBackground(v,silent=false){
 const maps={
  blueWhite:{bg:'#f5f8ff',dash:'blue',panel:'auto',product:'auto'},
  softPurple:{bg:'#f7f4ff',dash:'purple',panel:'plum',product:'auto'},
  ice:{bg:'#eef8ff',dash:'blue',panel:'navy',product:'blue'},
  mint:{bg:'#effcf6',dash:'green',panel:'emerald',product:'green'},
  rose:{bg:'#fff4f8',dash:'wine',panel:'wine',product:'auto'},
  warm:{bg:'#fff8ef',dash:'gold',panel:'gold',product:'auto'},
  midnight:{bg:'#080b14',dash:'midnight',panel:'obsidian',product:'black'},
  royal:{bg:'#eef2ff',dash:'royal',panel:'royal',product:'purple'},
  sunset:{bg:'#fff1ed',dash:'wine',panel:'gold',product:'auto'},
  forest:{bg:'#eefaf4',dash:'green',panel:'emerald',product:'green'},
  slate:{bg:'#eef1f5',dash:'charcoal',panel:'obsidian',product:'gray'},
  lavender:{bg:'#f5f1ff',dash:'purple',panel:'plum',product:'purple'},
  leaf:{bg:'#edf9ef',dash:'leaf',panel:'emerald',product:'green'},
  sunrise:{bg:'#fff5df',dash:'sunrise',panel:'gold',product:'auto'},
  ocean:{bg:'#e9f9ff',dash:'ocean',panel:'navy',product:'blue'},
  auroraGlow:{bg:'#f3efff',dash:'auroraGlow',panel:'plum',product:'purple'},
  sunsetGlow:{bg:'#fff0e8',dash:'sunsetGlow',panel:'wine',product:'auto'},
  paper:{bg:'#fffdf7',dash:'paper',panel:'auto',product:'white'}
 };
 const m=maps[v]||maps.blueWhite,root=document.documentElement;
 root.style.setProperty('--bg',m.bg);if(db?.settings){db.settings.appBg=v;db.settings.dashboardBg=m.dash;db.settings.panelBg=m.panel;db.settings.productBg=m.product;if(!silent){save();}}root.dataset.appbg=v;root.dataset.dashboardbg=m.dash;
 applyDashboardStyle();applyPanelBg(m.panel,true);applyProductBg(m.product,true);
 if(!silent)toast('সম্পূর্ণ Background থিম সেভ হয়েছে');
}
function applyTheme(t, silent=false){
 const allowed=['purple','blue','green','rose','orange','dark','sky','cream','mint'];if(!allowed.includes(t))t='purple';
 document.documentElement.dataset.theme=t;
 if(db&&db.settings){db.settings.theme=t;try{localStorage.setItem(KEY,JSON.stringify(db));}catch(_){}idbPut(db).catch(()=>{});}
 if(!silent)toast('অ্যাপের Background থিম: '+({purple:'পার্পল',blue:'ব্লু',green:'সবুজ',rose:'রোজ',orange:'অরেঞ্জ',dark:'ডার্ক',sky:'আকাশি',cream:'ক্রিম',mint:'মিন্ট'}[t]||t));
}
function page(id){
 document.querySelectorAll(".page").forEach(x=>x.classList.remove("active"));
 const target=document.getElementById(id); if(!target)return; target.classList.add("active");
 document.querySelectorAll(".nav").forEach(x=>x.classList.toggle("active",x.dataset.page===id));
 document.querySelectorAll(".bottom-nav button[data-page]").forEach(x=>x.classList.toggle("active",x.dataset.page===id));
 document.getElementById("side")?.classList.remove("open");
 render(id);
 window.scrollTo(0,0);
}
// Single, delegated navigation handler. It survives dashboard/page re-renders.
document.addEventListener("click", function(e){
  const nav=e.target.closest(".nav[data-page], .bottom-nav button[data-page]");
  if(nav){ e.preventDefault(); e.stopPropagation(); page(nav.dataset.page); return; }
});
window.openSideMenu=function(){
  const s=document.getElementById("side");
  if(!s)return false;
  s.classList.toggle("open");
  return false;
};
window.openSettings=function(){ page("settings"); };
window.openAbout=function(){ page("about"); };
document.getElementById("modalback")?.addEventListener("click",e=>{if(e.target.id==="modalback")closeModal()});

function openThemePicker(){const names={purple:'পার্পল',blue:'ব্লু',green:'সবুজ',rose:'রোজ',orange:'অরেঞ্জ',dark:'ডার্ক',sky:'আকাশি',cream:'ক্রিম',mint:'মিন্ট'};const sw={purple:'#6c57f5',blue:'#3b82f6',green:'#16a56b',rose:'#e85d8b',orange:'#f08a24',dark:'#202031',sky:'#0ea5e9',cream:'#9a6b22',mint:'#059669'};modal(`<div class="modalhead"><div><h2 style="margin:0">🎨 Background / থিম</h2><div class="theme-current">বর্তমান: ${esc(names[db.settings.theme]||'পার্পল')}</div></div><button class="close" onclick="closeModal()">✕</button></div><div class="theme-help">যে থিমে চাপবেন সেটি সঙ্গে সঙ্গে পুরো অ্যাপের Background ও রঙে প্রয়োগ হবে এবং সেভ থাকবে।</div><div class="theme-picker">${Object.keys(names).map(k=>`<button class="theme-choice ${db.settings.theme===k?'active':''}" onclick="applyTheme('${k}');openThemePicker()"><div class="theme-swatch" style="background:linear-gradient(135deg,${sw[k]},#ffffff33)"></div>${names[k]}</button>`).join('')}</div><button class="btn secondary" style="width:100%;margin-top:14px" onclick="page('settings');closeModal()">⚙ বিস্তারিত সেটিংস</button>`)}
function applyLogo(src){const img=document.getElementById('shopLogo'); if(!img)return; const fallback='branding/business360_logo.png'; if(db?.settings?.logoRemoved && !src){img.removeAttribute('src');img.classList.remove('show');return;} const value=src || fallback; img.onerror=()=>{if(value!==fallback){img.src=fallback;}else{img.classList.add('show')}}; img.src=value; img.classList.add('show')}
function saveLogoFile(file){
 if(!file)return;
 if(!/^image\//.test(file.type)){toast('শুধু ছবি নির্বাচন করুন');return}
 if(file.size>12*1024*1024){toast('লোগো ১২ MB-এর মধ্যে রাখুন');return}
 const reader=new FileReader();reader.onload=()=>{
  const img=new Image();img.onload=()=>{
   const max=720,scale=Math.min(1,max/Math.max(img.width,img.height));
   const c=document.createElement('canvas');c.width=Math.max(1,Math.round(img.width*scale));c.height=Math.max(1,Math.round(img.height*scale));
   const ctx=c.getContext('2d');ctx.fillStyle='#fff';ctx.fillRect(0,0,c.width,c.height);ctx.drawImage(img,0,0,c.width,c.height);
   let data=c.toDataURL('image/jpeg',.82);
   if(data.length>900000)data=c.toDataURL('image/jpeg',.68);
   try{db.settings.logo=data;db.settings.logoRemoved=false;save();applyLogo(data);settingsPage();toast('দোকানের নতুন Logo সেভ হয়েছে')}catch(e){toast('Logo সেভ হয়নি — ছোট ছবি চেষ্টা করুন')}};img.onerror=()=>toast('Logo ছবিটি পড়া যায়নি');img.src=reader.result;
 };reader.onerror=()=>toast('Logo ফাইল পড়া যায়নি');reader.readAsDataURL(file);
}
let dashboardExpanded=false;
let dashboardArrangeMode=false;
function toggleDashboardArrange(){
 dashboardArrangeMode=!dashboardArrangeMode;
 save();
 dashboard();
 toast(dashboardArrangeMode ? "বক্স সাজানোর মোড চালু হয়েছে" : "বক্সের নতুন অবস্থান সেভ হয়েছে");
}
function toggleDashboardExtras(){dashboardExpanded=!dashboardExpanded;dashboard();}
function dashboard(){
 const sales=db.sales.filter(x=>!x.cancelled), purs=db.purchases.filter(x=>!x.cancelled);
 const saleReturns=db.returns.filter(r=>r.type==="sale"); const totalSales=sales.reduce((a,x)=>a+num(x.total),0)-saleReturns.reduce((a,r)=>a+num(r.amount),0);
 const totalPurchase=purs.reduce((a,x)=>a+num(x.total),0);
 const totalExpense=db.expenses.reduce((a,x)=>a+num(x.amount),0);
 const totalCogs=sales.reduce((a,s)=>a+s.items.reduce((q,i)=>q+num(i.qty)*num(i.cost),0),0)-saleReturns.reduce((a,r)=>{const s=sales.find(x=>x.id===r.refId),i=s?.items?.[r.itemIndex];return a+(i?num(r.qty)*num(i.cost):0)},0); const totalProfit=totalSales-totalCogs-totalExpense;
 const cashIn=sales.filter(x=>x.date===today()).reduce((a,x)=>a+num(x.paid),0);
 const todayExpense=db.expenses.filter(x=>x.date===today()).reduce((a,x)=>a+num(x.amount),0);
 const cashOut=purs.filter(x=>x.date===today()).reduce((a,x)=>a+num(x.paid),0)+todayExpense;
 const dueC=db.customers.reduce((a,x)=>a+partyDue('customer',x.id),0);
 const stockQty=db.products.reduce((a,p)=>a+num(p.stock),0);
 const stockValue=db.products.reduce((a,p)=>a+num(p.stock)*num(p.costPrice),0);
 const netCash=Math.max(0,cashIn-cashOut);
 const defs=['income','expense','products','parties','sales','purchase','dues','stock','stockValue','profit'];
 let order=(Array.isArray(db.settings.dashboardOrder)?db.settings.dashboardOrder.slice():defs.slice()).filter(k=>defs.includes(k));
 defs.forEach(k=>{if(!order.includes(k))order.push(k)});
 const info={
  income:['💰','মোট আয়',money(totalSales),'সব বিক্রয়ের মোট','reports'],
  expense:['💸','মোট ব্যয়',money(totalExpense),'সব খরচের মোট','expenses'],
  products:['📦','মোট পণ্য',db.products.length.toLocaleString('bn-BD'),'বর্তমান পণ্য সংখ্যা','products'],
  parties:['👥','মোট পার্টি',(db.customers.length+db.suppliers.length).toLocaleString('bn-BD'),'Customer + Supplier','parties'],
  sales:['🛒','মোট বিক্রি',money(totalSales),'বিক্রয় মোট','sale'],
  purchase:['🛍️','মোট ক্রয়',money(totalPurchase),'ক্রয়ের মোট','purchase'],
  dues:['🧾','মোট বকেয়া',money(dueC),'কাস্টমারের পাওনা','dues'],
  stock:['📦','মোট স্টক',stockQty.toLocaleString('bn-BD')+' '+(db.products[0]?.unit||'pcs'),'বর্তমান স্টক পরিমাণ','products'],
  stockValue:['💎','স্টক মূল্য',money(stockValue),'ক্রয়মূল্য অনুযায়ী','reports'],
  profit:['📈','লাভ / ক্ষতি',money(totalProfit),'বিক্রয় − ক্রয় − ব্যয়','reports']
 };
 const card=(key)=>{const [icon,name,value,small,target]=info[key];const controls=dashboardArrangeMode?`<div class="move-tools" onclick="event.stopPropagation()"><button onclick="moveDashboardCard('${key}',-2)" title="উপরে">↑</button><button onclick="moveDashboardCard('${key}',2)" title="নিচে">↓</button><button onclick="moveDashboardCard('${key}',-1)" title="বামে">←</button><button onclick="moveDashboardCard('${key}',1)" title="ডানে">→</button></div>`:'';return `<div class="dash-card dc-${key} ${dashboardArrangeMode?'arrange-card':''}" data-card-key="${key}" draggable="${dashboardArrangeMode}" onclick="${dashboardArrangeMode?'event.stopPropagation()':'page(\''+target+'\')'}"><div class="card-inner"><div class="ico">${icon}</div><div class="card-copy"><div class="name">${name}</div><div class="small">${small}</div><div class="big">${value}</div></div><div class="arrow">›</div>${controls}</div></div>`};
 const visible=dashboardArrangeMode?order.map(card).join(''):order.slice(0,6).map(card).join('');
 const extras=dashboardArrangeMode?'':order.slice(6).map(card).join('');
 const recent=[
  ...sales.slice(-3).map(x=>({icon:'🛒',name:'পণ্য বিক্রি',party:(db.customers.find(c=>c.id===x.customerId)?.name||'ক্যাশ বিক্রি'),amount:x.total,date:x.date})),
  ...purs.slice(-3).map(x=>({icon:'🛍️',name:'পণ্য ক্রয়',party:(db.suppliers.find(c=>c.id===x.supplierId)?.name||'সাপ্লায়ার'),amount:x.total,date:x.date})),
  ...db.payments.slice(-3).map(x=>({icon:'👤',name:x.type==='customer'?'পার্টি → বাকি':'পার্টি পেমেন্ট',party:(db.customers.find(c=>c.id===x.partyId)?.name||db.suppliers.find(c=>c.id===x.partyId)?.name||'পার্টি'),amount:x.amount,date:(x.date||'').slice(0,10)}))
 ].sort((a,b)=>String(b.date).localeCompare(String(a.date))).slice(0,3);
 document.getElementById('dashboard').innerHTML=`
 <div class="dash-stage border-${db.settings.dashboardBorder||'soft'}"><div class="dash">
  ${dashboardArrangeMode?`<div class="arrange-banner"><b>🧩 বক্স সাজানোর মোড</b><span>সব ১০টি বক্স এখানে দেখা যাবে। ↑ ↓ ← → বা বক্স টেনে অন্য বক্সের ওপর ফেলুন; নতুন অবস্থান সঙ্গে সঙ্গে সেভ হবে।</span><button class="btn sm" onclick="toggleDashboardArrange()">✓ শেষ করুন</button></div>`:''}
  <div class="dash-hero"><div class="dash-hero-top"><div><div style="font-size:17px;opacity:.95">হাতে আছে</div><div class="dash-balance">${money(netCash)}</div></div><button class="icon" style="background:#ffffff20" onclick="toast('আজকের নগদ হিসাব')">◉</button></div><div class="dash-mini"><div><div class="lbl">নগদ প্রাপ্তি</div><div class="amt">${money(cashIn)}</div></div><div><div class="lbl">নগদ প্রদান</div><div class="amt">${money(cashOut)}</div></div></div></div>
  <div class="dash-cards premium-8">${visible}</div>
  <button class="dash-see-all ${dashboardExpanded?'expanded':''}" onclick="toggleDashboardExtras()">${dashboardExpanded?'কম দেখান ↑':'সব দেখুন →'}</button>
  ${!dashboardArrangeMode&&dashboardExpanded?`<div class="dash-extra-grid">${extras}</div>`:''}
  <div class="dash-list"><div class="dash-list-head"><div><b>সাম্প্রতিক লেনদেন</b><div class="sub">সর্বশেষ বিক্রি, ক্রয় ও পেমেন্ট</div></div><button class="dash-see" onclick="page('reports')">আরও দেখুন ›</button></div>
   ${recent.map(r=>`<div class="dash-list-row"><div class="left"><div class="round">${r.icon}</div><div><b>${esc(r.name)}</b><div class="sub">${esc(r.party||'')}</div></div></div><div class="right"><b>${money(r.amount)}</b><div class="sub">${esc(r.date||'')}</div></div></div>`).join('')||'<div class="empty">এখনও কোনো লেনদেন নেই।</div>'}
  </div>
  <div class="dash-actions"><div class="dash-action action-purple" onclick="page('purchase')">🛒 &nbsp; নতুন ক্রয়</div><div class="dash-plus" onclick="openQuickMenu()">+</div><div class="dash-action action-blue" onclick="page('sale')">🛍️ &nbsp; নতুন বিক্রি</div></div>
  ${!dashboardArrangeMode?`<button class="dashboard-arrange-toggle" onclick="toggleDashboardArrange()">🧩 বক্স সাজান</button>`:''}
 </div></div>`;
 if(dashboardArrangeMode)enableDashboardDrag();
}
function moveDashboardCard(key,delta){
 const defs=['income','expense','products','parties','sales','purchase','dues','stock','stockValue','profit'];
 let a=(Array.isArray(db.settings.dashboardOrder)?db.settings.dashboardOrder.slice():defs.slice()).filter(k=>defs.includes(k));
 defs.forEach(k=>{if(!a.includes(k))a.push(k)});
 const i=a.indexOf(key),j=i+delta;if(i<0||j<0||j>=a.length)return;
 [a[i],a[j]]=[a[j],a[i]];db.settings.dashboardOrder=a;save();dashboard();
}
function enableDashboardDrag(){
 const cards=[...document.querySelectorAll('.arrange-card')];
 let dragged=null, sx=0, sy=0, moved=false, targetKey=null;
 const orderNow=()=>{const defs=['income','expense','products','parties','sales','purchase','dues','stock','stockValue','profit'];let o=Array.isArray(db.settings.dashboardOrder)?db.settings.dashboardOrder.slice():defs.slice();o=o.filter(k=>defs.includes(k));defs.forEach(k=>{if(!o.includes(k))o.push(k)});return o};
 const reorder=(a,b)=>{if(!a||!b||a===b)return false;const ka=a.dataset.cardKey,kb=b.dataset.cardKey;let order=orderNow();const ia=order.indexOf(ka),ib=order.indexOf(kb);if(ia<0||ib<0||ia===ib)return false;order.splice(ia,1);order.splice(ib,0,ka);db.settings.dashboardOrder=order;save();dashboard();return true;};
 const clearTarget=()=>{cards.forEach(c=>c.classList.remove('drag-over'));targetKey=null;};
 const findTarget=(x,y)=>{
   if(!dragged)return null;
   const oldVis=dragged.style.visibility; dragged.style.visibility='hidden';
   const hit=document.elementFromPoint(x,y);
   dragged.style.visibility=oldVis;
   const t=hit?.closest?.('.arrange-card');
   return t&&t!==dragged?t:null;
 };
 cards.forEach(el=>{
  el.addEventListener('dragstart',()=>{dragged=el;el.classList.add('dragging')});
  el.addEventListener('dragend',()=>{if(dragged)dragged.classList.remove('dragging');dragged=null;clearTarget()});
  el.addEventListener('dragover',e=>{e.preventDefault();clearTarget();el.classList.add('drag-over');targetKey=el.dataset.cardKey});
  el.addEventListener('dragleave',()=>el.classList.remove('drag-over'));
  el.addEventListener('drop',e=>{e.preventDefault();const a=dragged;const ok=reorder(a,el);dragged=null;clearTarget();if(ok)toast('বক্সের নতুন অবস্থান সেভ হয়েছে')});
  el.addEventListener('touchstart',e=>{
    if(e.touches.length!==1)return;
    dragged=el;const t=e.touches[0];sx=t.clientX;sy=t.clientY;moved=false;targetKey=null;el.classList.add('dragging');
  },{passive:true});
  el.addEventListener('touchmove',e=>{
    if(!dragged||e.touches.length!==1)return;
    const t=e.touches[0];
    if(Math.abs(t.clientX-sx)+Math.abs(t.clientY-sy)>8)moved=true;
    if(!moved)return;
    e.preventDefault();
    const target=findTarget(t.clientX,t.clientY);
    clearTarget();
    if(target){target.classList.add('drag-over');targetKey=target.dataset.cardKey;}
  },{passive:false});
  el.addEventListener('touchend',e=>{
    if(!dragged)return;
    const a=dragged;const t=e.changedTouches[0];
    const target=moved?findTarget(t.clientX,t.clientY):null;
    a.classList.remove('dragging');clearTarget();dragged=null;
    if(moved&&target){reorder(a,target);toast('বক্সের নতুন অবস্থান সেভ হয়েছে');}
  },{passive:true});
  el.addEventListener('touchcancel',()=>{if(dragged)dragged.classList.remove('dragging');dragged=null;clearTarget()},{passive:true});
 });
}

function openQuickMenu(){modal(`<div class="modalhead"><h2>দ্রুত কাজ</h2><button class="close" onclick="closeModal()">×</button></div><div class="grid g2"><button class="btn" onclick="closeModal();page('sale')">🛒 নতুন বিক্রয়</button><button class="btn secondary" onclick="closeModal();page('purchase')">🛍 নতুন ক্রয়</button><button class="btn secondary" onclick="closeModal();openProductForm()">📦 নতুন পণ্য</button><button class="btn secondary" onclick="closeModal();openPartyForm('customer')">👤 নতুন Customer</button><button class="btn secondary" onclick="closeModal();openPartyForm('supplier')">🏢 নতুন Supplier</button><button class="btn secondary" onclick="closeModal();openExpenseForm()">💸 খরচ যোগ</button></div>`)}

function partyDue(type,id){const arr=type==="customer"?db.customers:db.suppliers;const p=arr.find(x=>x.id===id);if(!p)return 0;
 if(type==="customer"){return p.openingDue + db.sales.filter(s=>s.customerId===id&&!s.cancelled).reduce((a,s)=>a+s.due,0)-db.returns.filter(r=>r.type==="sale" && db.sales.find(s=>s.id===r.refId)?.customerId===id).reduce((a,r)=>a+r.amount,0)-db.payments.filter(x=>x.type==="customer"&&x.partyId===id).reduce((a,x)=>a+x.amount,0)}
 return p.openingDue + db.purchases.filter(s=>s.supplierId===id&&!s.cancelled).reduce((a,s)=>a+s.due,0)-db.returns.filter(r=>r.type==="purchase" && db.purchases.find(s=>s.id===r.refId)?.supplierId===id).reduce((a,r)=>a+r.amount,0)-db.payments.filter(x=>x.type==="supplier"&&x.partyId===id).reduce((a,x)=>a+x.amount,0)
}

function salePage(){
 const total=saleCart.reduce((a,i)=>a+i.qty*i.price,0), cost=saleCart.reduce((a,i)=>a+i.qty*i.cost,0);
 document.getElementById("sale").innerHTML=`
 <div class="title"><div><h1>নতুন বিক্রয়</h1><div class="sub">এক Invoice-এ একাধিক পণ্য · Barcode / Search · লাভ অটো হিসাব</div></div><button class="btn gray" onclick="clearSale()">নতুন Cart</button></div>
 <div class="grid g2">
 <div class="card">
  <div class="formrow"><div class="field"><label>Barcode / পণ্য খুঁজুন</label><input id="saleSearch" class="input" placeholder="Barcode scan বা নাম লিখুন" autofocus></div>
  <div class="field"><label>Customer</label><select id="saleCustomer" class="select">${partyOptions("customer")}</select></div></div>
  <div class="toolbar"><button class="btn secondary" onclick="openProductPicker('sale')">পণ্য নির্বাচন</button><button class="btn secondary" onclick="scanBarcode('sale')">📷 Camera Scan</button><button class="btn secondary" onclick="quickParty('customer')">+ Customer</button></div>
  <div class="section">${saleCart.length?saleCart.map((i,k)=>`<div class="cartrow"><div><b>${esc(i.name)}</b><div class="sub">${esc(i.barcode||"")} · ক্রয় ${money(i.cost)}</div></div><div class="qty"><input class="input qty-input" type="number" min="1" max="${Math.max(1,db.products.find(x=>x.id===i.productId)?.stock||1)}" value="${i.qty}" onchange="setSaleQty(${k},this.value)"></div><input class="input" type="number" min="0" step=".01" value="${i.price}" onchange="setSalePrice(${k},this.value)"><button class="btn danger sm" onclick="saleCart.splice(${k},1);render('sale')">×</button></div>`).join(""):`<div class="empty">Cart খালি। Barcode scan করুন বা পণ্য নির্বাচন করুন।</div>`}</div>
 </div>
 <div class="card">
  <h3>Invoice / Payment</h3>
  <div class="totalbox"><div class="totalline"><span>মোট মূল্য</span><b>${money(total)}</b></div><div class="totalline"><span>লাভ (পণ্যভিত্তিক)</span><b>${money(total-cost)}</b></div></div>
  <div class="formrow section"><div class="field"><label>Discount</label><input id="saleDisc" class="input" type="number" min="0" value="0"></div><div class="field"><label>VAT / অতিরিক্ত</label><input id="saleTax" class="input" type="number" min="0" value="0"></div></div>
  <div class="formrow"><div class="field"><label>Payment</label><select id="salePay" class="select"><option>Cash</option><option>Bank</option><option>Mobile Banking</option><option>Card</option></select></div><div class="field"><label>Paid Amount</label><input id="salePaid" class="input" type="number" min="0" value="${total}"></div></div>
  <div class="field"><label>বর্ণনা / Note</label><textarea id="saleNote" class="textarea" placeholder="ঐচ্ছিক"></textarea></div>
  <div class="save-bar"><button id="completeSaleBtn" class="btn save-primary" style="flex:1" onclick="completeSale()">💾 বিক্রয় সেভ ও Invoice</button><span class="save-hint">একবার চাপুন • সেভ হলে ✓ দেখাবে</span></div>
  <div class="sub section">Paid কম হলে Customer Due তৈরি হবে। Stock স্বয়ংক্রিয়ভাবে কমবে।</div>
 </div></div>`;
 const inp=document.getElementById("saleSearch");
 inp.onkeydown=e=>{if(e.key==="Enter"){e.preventDefault();quickScanValue(inp.value);inp.value=""}};
}
function quickScanValue(v){v=String(v||"").trim();if(!v)return;let p=db.products.find(x=>String(x.barcode||"")===v);if(!p)p=db.products.find(x=>x.name.toLowerCase().includes(v.toLowerCase()));if(p)addSale(p.id);else toast("পণ্য পাওয়া যায়নি")}
function addSale(pid){const p=db.products.find(x=>x.id===pid);if(!p)return;if(p.stock<=0){toast("এই পণ্যের স্টক নেই");return}let i=saleCart.find(x=>x.productId===pid);if(i){if(i.qty>=p.stock){toast("স্টক শেষ");return}i.qty++}else saleCart.push({productId:p.id,name:p.name,barcode:p.barcode,cost:num(p.costPrice),price:num(p.salePrice),qty:1});render("sale")}
function chgSale(k,d){const i=saleCart[k],p=db.products.find(x=>x.id===i.productId);i.qty=Math.max(1,Math.min(p.stock,i.qty+d));render("sale")}
function setSaleQty(k,v){const i=saleCart[k],p=db.products.find(x=>x.id===i.productId);if(!i||!p)return;i.qty=Math.max(1,Math.min(p.stock,num(v)||1));render("sale")}
function setSalePrice(k,v){saleCart[k].price=Math.max(0,num(v));render("sale")}
function clearSale(){saleCart=[];render("sale")}
function completeSale(){
 if(savingSale)return;
 if(!saleCart.length){toast("আগে পণ্য যোগ করুন");return}
 savingSale=true;const saveBtn=document.getElementById("completeSaleBtn");if(saveBtn){saveBtn.disabled=true;saveBtn.textContent="⏳ বিক্রয় সেভ হচ্ছে...";saveBtn.style.opacity=".7"}
 const customerId=document.getElementById("saleCustomer")?.value||"", disc=num(document.getElementById("saleDisc")?.value),tax=num(document.getElementById("saleTax")?.value);
 const subtotal=saleCart.reduce((a,i)=>a+i.qty*i.price,0), total=Math.max(0,subtotal-disc+tax), paid=Math.min(total,Math.max(0,num(document.getElementById("salePaid")?.value)));
 for(const i of saleCart){const p=db.products.find(x=>x.id===i.productId);if(!p||i.qty>p.stock){savingSale=false;toast("স্টক পরিবর্তিত হয়েছে; Cart পরীক্ষা করুন");return}}
 const s={id:uid("S"),invoice:nextNo("sale"),date:today(),time:new Date().toLocaleTimeString("bn-BD"),customerId,customerName:db.customers.find(x=>x.id===customerId)?.name||"Walk-in",items:clone(saleCart),subtotal,discount:disc,tax,total,paid,due:total-paid,payment:document.getElementById("salePay")?.value||"Cash",note:document.getElementById("saleNote")?.value||""};
 s.profit=saleCart.reduce((a,i)=>a+i.qty*(i.price-i.cost),0)-disc+tax;
 db.sales.push(s);saleCart.forEach(i=>{const p=db.products.find(x=>x.id===i.productId);p.stock-=i.qty;addMove(p.id,-i.qty,"SALE",s.invoice)});
 save();saleCart=[];render("sale");showInvoice(s,"sale");savingSale=false;toast("✓ বিক্রয় সফলভাবে সেভ হয়েছে");
}
function showInvoice(s,type="sale"){const party=type==="sale"?db.customers.find(x=>x.id===s.customerId):db.suppliers.find(x=>x.id===s.supplierId);const partyName=party?.name||(type==="sale"?s.customerName:s.supplierName)||"Walk-in";const title=type==="sale"?"বিক্রয় রসিদ":"ক্রয় রসিদ";
 modal(`<div class="invoice" id="printInvoice"><div class="center"><h2>${esc(db.settings.shop)}</h2><div>${esc(db.settings.address)}</div><div>${esc(db.settings.phone)}</div><div class="divider"></div><h3>${title}</h3></div>
 <div class="totalline"><span>নং: ${esc(s.invoice)}</span><span>তারিখ: ${esc(s.date)}</span></div><div>Party: ${esc(partyName)}</div><div class="divider"></div>
 <table class="table"><tr><th>পণ্য</th><th>Qty</th><th>Rate</th><th class="right">Amount</th></tr>${s.items.map((i,k)=>`<tr><td><input id="invName${k}" class="input invoice-name-input" value="${esc(i.name)}"></td><td>${i.qty}</td><td>${money(i.price)}</td><td class="right">${money(i.qty*i.price)}</td></tr>`).join("")}</table>
 <div class="totalline"><span>Subtotal</span><b>${money(s.subtotal)}</b></div><div class="totalline"><span>Discount</span><b>${money(s.discount)}</b></div><div class="totalline"><span>Tax/Extra</span><b>${money(s.tax)}</b></div><div class="totalline grand"><span>Total</span><b>${money(s.total)}</b></div><div class="totalline"><span>Paid</span><b>${money(s.paid)}</b></div><div class="totalline"><span>Due</span><b>${money(s.due)}</b></div><p>${esc(s.note||"ধন্যবাদ")}</p></div><div class="toolbar no-print" style="margin-top:12px"><button class="btn ok" onclick="saveInvoiceNames('${s.id}','${type}')">✏️ পণ্যের নাম সেভ</button><button class="btn" onclick="printInvoice()">🖨 Print</button><button class="btn secondary" onclick="closeModal()">বন্ধ</button></div>`)}
function saveInvoiceNames(id,type){const arr=type==="sale"?db.sales:db.purchases;const s=arr.find(x=>x.id===id);if(!s)return;s.items.forEach((it,k)=>{const el=document.getElementById("invName"+k);if(el&&el.value.trim())it.name=el.value.trim()});save();showInvoice(s,type);toast("ইনভয়েসের পণ্যের নাম সেভ হয়েছে")}
function printInvoice(){window.print()}

function transactionsPage(){
 const rows=[];
 db.sales.filter(x=>!x.cancelled).forEach(x=>rows.push({date:x.date||'',time:x.time||'',type:'বিক্রি',party:x.customerName||'Walk-in',invoice:x.invoice||'',amount:num(x.total),id:x.id,kind:'sale'}));
 db.purchases.filter(x=>!x.cancelled).forEach(x=>rows.push({date:x.date||'',time:'',type:'ক্রয়',party:x.supplierName||'Supplier',invoice:x.invoice||'',amount:num(x.total),id:x.id,kind:'purchase'}));
 db.payments.forEach(x=>rows.push({date:x.date||'',time:'',type:x.type==='customer'?'পাওনা আদায়':'Supplier পরিশোধ',party:x.partyName||'',invoice:'',amount:num(x.amount),id:x.id,kind:'payment'}));
 db.expenses.forEach(x=>rows.push({date:x.date||'',time:'',type:'খরচ',party:x.category||'',invoice:'',amount:num(x.amount),id:x.id,kind:'expense'}));
 db.returns.forEach(x=>rows.push({date:x.date||'',time:'',type:x.type==='sale'?'বিক্রয় রিটার্ন':'ক্রয় রিটার্ন',party:'',invoice:x.invoice||'',amount:num(x.amount),id:x.id,kind:'return'}));
 rows.sort((a,b)=>String(b.date+b.time).localeCompare(String(a.date+a.time)));
 const totalSales=db.sales.filter(x=>!x.cancelled).reduce((a,x)=>a+num(x.total),0), totalPurchase=db.purchases.filter(x=>!x.cancelled).reduce((a,x)=>a+num(x.total),0);
 document.getElementById('transactions').innerHTML=`<div class="title"><div><h1>লেনদেন</h1><div class="sub">বিক্রি, ক্রয়, পেমেন্ট, খরচ ও রিটার্ন—সব এক জায়গায়</div></div><div class="toolbar"><button class="btn" onclick="page('sale')">＋ নতুন বিক্রি</button><button class="btn secondary" onclick="page('purchase')">＋ নতুন ক্রয়</button></div></div>
 <div class="grid g2"><div class="card"><div class="label">মোট বিক্রি</div><div class="value">${money(totalSales)}</div></div><div class="card"><div class="label">মোট ক্রয়</div><div class="value">${money(totalPurchase)}</div></div></div>
 <div class="card section"><div class="toolbar"><input id="txSearch" class="input search" placeholder="Invoice / Party / ধরন খুঁজুন"></div><div id="txList"></div></div>`;
 const draw=()=>{const q=(document.getElementById('txSearch').value||'').trim().toLowerCase();const arr=rows.filter(r=>!q||[r.type,r.party,r.invoice,r.date].join(' ').toLowerCase().includes(q));document.getElementById('txList').innerHTML=arr.map(r=>`<div class="totalline" style="padding:12px 0;border-bottom:1px solid var(--line)"><span><b>${esc(r.type)}</b> · ${esc(r.party||'')}</span><span><b>${money(r.amount)}</b><br><small>${esc(r.invoice||'')} · ${esc(r.date)}</small></span></div>`).join('')||'<div class="empty">কোনো লেনদেন পাওয়া যায়নি।</div>'};
 document.getElementById('txSearch').oninput=draw;draw();
}

function purchasePage(){
 const total=purchaseCart.reduce((a,i)=>a+i.qty*i.cost,0);
 const selectedSupplier=document.getElementById('purSupplier')?.value||'';
 document.getElementById("purchase").innerHTML=`
 <div class="title"><div><h1>নতুন ক্রয়</h1><div class="sub">Supplier → আগের কেনা পণ্য → নতুন আইটেম → Quantity → Total → Save</div></div><button class="btn gray" onclick="purchaseCart=[];render('purchase')">নতুন ক্রয়</button></div>
 <div class="card">
  <div class="formrow"><div class="field"><label>বিল নম্বর</label><input id="purBill" class="input" value="${nextPurchasePreview()}"></div><div class="field"><label>তারিখ</label><input id="purDate" class="input" type="date" value="${today()}"></div></div>
  <div class="formrow"><div class="field"><label>Supplier / Party</label><select id="purSupplier" class="select" onchange="renderPurchaseSupplierHistory()">${partyOptions("supplier",selectedSupplier)}</select><div class="purchase-party-tools"><button class="btn secondary sm" type="button" onclick="quickPurchaseSupplier()">＋ নতুন Supplier</button><button class="btn gray sm" type="button" onclick="editPurchaseSupplier()">✎ Supplier Edit</button></div><div id="purchaseSupplierHistory">${purchaseSupplierHistoryHtml(selectedSupplier)}</div></div><div class="field"><label>Payment Type</label><select id="purType" class="select"><option value="cash">Cash</option><option value="credit">Credit</option></select></div></div>
  <button class="btn secondary" type="button" onclick="openProductPicker('purchase')">＋ আগে থেকে থাকা পণ্য</button>
  <button class="btn ok" type="button" onclick="openNewPurchaseItem()">＋ নতুন আইটেম / পণ্য</button>
  <div class="section">${purchaseCart.length?purchaseCart.map((i,k)=>`<div class="cartrow"><div class="purchase-item-name"><input class="input" value="${esc(i.name)}" onchange="setPurName(${k},this.value)"><div class="sub">ক্রয় মূল্য ${money(i.cost)}${i.productId?'':' · নতুন আইটেম'}</div></div><div class="qty"><input class="input qty-input" type="number" min="1" value="${i.qty}" onchange="setPurQty(${k},this.value)"></div><input class="input" type="number" min="0" step=".01" value="${i.cost}" onchange="setPurCost(${k},this.value)"><button class="btn danger sm" onclick="purchaseCart.splice(${k},1);render('purchase')">×</button></div>`).join(""):`<div class="empty">কোনো আইটেম নেই। আগের পণ্য বেছে নিন অথবা নতুন আইটেম যোগ করুন।</div>`}</div>
  <div class="grid g2 section"><div>
   <div class="field"><label>নতুন পণ্য</label><button class="btn secondary" onclick="openNewPurchaseItem()">＋ নাম, Quantity ও মূল্য একসাথে দিন</button></div>
   <div class="field"><label>বর্ণনা (০/২৫০)</label><textarea id="purNote" class="textarea"></textarea></div>
  </div><div>
   <div class="totalbox panel-theme"><div class="totalline"><span>মোট মূল্য</span><b>${money(total)}</b></div><div class="totalline"><span>সর্বমোট মূল্য</span><b>${money(total)}</b></div><div class="totalline"><span>পরিশোধিত মূল্য</span><input id="purPaid" class="input" type="number" min="0" value="${document.getElementById('purPaid')?.value||total}"></div><div class="totalline grand"><span>বাকি</span><b>${money(Math.max(0,total-num(document.getElementById('purPaid')?.value||total)))}</b></div></div>
  </div></div>
  <div class="save-bar section"><button id="completePurchaseBtn" class="btn save-primary" style="flex:1" onclick="completePurchase()">💾 ক্রয় সেভ করুন</button><span class="save-hint">একবার চাপুন • সেভ হলে ✓ দেখাবে</span></div>
 </div>`;
}
function renderPurchaseSupplierHistory(){const id=document.getElementById('purSupplier')?.value||'';const el=document.getElementById('purchaseSupplierHistory');if(el)el.innerHTML=purchaseSupplierHistoryHtml(id)}
function purchaseSupplierHistoryHtml(supplierId){
 if(!supplierId)return '<div class="sub" style="margin-top:8px">Supplier নির্বাচন করলে তার কাছ থেকে আগে কেনা পণ্য এখানে দেখাবে।</div>';
 const seen=new Set(), items=[];
 db.purchases.filter(x=>x.supplierId===supplierId&&!x.cancelled).slice().reverse().forEach(p=>p.items.forEach(i=>{const key=i.productId||('name:'+String(i.name||'').toLowerCase());if(!seen.has(key)){seen.add(key);items.push(i)}}));
 if(!items.length)return '<div class="purchase-history"><div class="purchase-history-title">📦 এই Supplier-এর আগের পণ্য</div><div class="sub" style="color:#c6c2d5!important">আগে কোনো পণ্য কেনা হয়নি।</div></div>';
 return `<div class="purchase-history"><div class="purchase-history-title">📦 এই Supplier-এর কাছ থেকে আগে কেনা পণ্য</div><div class="purchase-history-list">${items.slice(0,12).map(i=>`<div class="purchase-history-item"><div><b>${esc(i.name)}</b><div class="sub">আগের ক্রয় মূল্য ${money(i.cost)} · আগের Qty ${i.qty}</div></div><button class="btn sm" onclick="quickAddPurchaseHistory('${esc(i.productId||'')}','${encodeURIComponent(i.name||'')}','${num(i.cost)}')">যোগ</button></div>`).join('')}</div></div>`;
}
function quickAddPurchaseHistory(pid,encName,cost){const name=decodeURIComponent(encName||'');if(pid){addPurchase(pid);return}let i=purchaseCart.find(x=>!x.productId&&x.name===name);if(i)i.qty++;else purchaseCart.push({productId:'',name,cost:num(cost),qty:1});render('purchase')}
function openNewPurchaseItem(){
 modal(`<div class="modalhead"><div><h2>নতুন আইটেম / পণ্য</h2><div class="sub">একবারেই নাম, Quantity ও মূল্য দিন—বারবার + চাপতে হবে না।</div></div><button class="close" onclick="closeModal()">×</button></div>
 <div class="field"><label>পণ্যের নাম *</label><input id="newPurName" class="input" placeholder="যেমন: লুঙ্গি, শার্ট, গামছা"></div>
 <div class="purchase-new-item"><div class="field"><label>Quantity *</label><input id="newPurQty" class="input" type="number" min="1" value="1"></div><div class="field"><label>ক্রয় মূল্য</label><input id="newPurCost" class="input" type="number" min="0" step=".01" value="0"></div><div class="field"><label>বিক্রয় মূল্য</label><input id="newPurSale" class="input" type="number" min="0" step=".01" value="0"></div><div class="field"><label>Barcode</label><input id="newPurBarcode" class="input" placeholder="ঐচ্ছিক"></div></div>
 <div class="field"><label>Category</label><input id="newPurCat" class="input" list="purchaseCategorySuggestions" autocomplete="off" placeholder="যেমন: পোশাক">${categoryDatalist("purchaseCategorySuggestions")}</div><button id="saveNewPurchaseItemBtn" class="btn" style="width:100%" onclick="saveNewPurchaseItem()">পণ্যে যোগ করুন</button>`);
}
function saveNewPurchaseItem(){
 const name=document.getElementById('newPurName').value.trim(),qty=Math.max(1,Math.floor(num(document.getElementById('newPurQty').value)||1)),cost=Math.max(0,num(document.getElementById('newPurCost').value)),sale=Math.max(0,num(document.getElementById('newPurSale').value));
 if(!name){toast('পণ্যের নাম দিন');return}
 const barcode=document.getElementById('newPurBarcode').value.trim(),cat=document.getElementById('newPurCat').value.trim();
 let p=db.products.find(x=>barcode&&x.barcode===barcode)||db.products.find(x=>x.name.trim().toLowerCase()===name.toLowerCase());
 if(!p){p={id:uid('PR'),name,barcode,category:cat,unit:'pcs',reorder:0,costPrice:cost,salePrice:sale,stock:0,description:''};db.products.push(p)}else{p.name=name;if(cost>0)p.costPrice=cost;if(sale>0)p.salePrice=sale;if(barcode)p.barcode=barcode;if(cat)p.category=cat}
 const existing=purchaseCart.find(x=>x.productId===p.id);if(existing){existing.qty+=qty;existing.cost=cost||existing.cost}else purchaseCart.push({productId:p.id,name,cost,qty});save();closeModal();render('purchase');toast('নতুন পণ্য/আইটেম যোগ হয়েছে');
}

function quickPurchaseSupplier(){
 const old=Array.from(document.querySelectorAll('#purchase select')).find(x=>x.id==='purSupplier')?.value||'';
 modal(`<div class="modalhead"><h2>নতুন Supplier</h2><button class="close" onclick="closeModal()">×</button></div><div class="field"><label>Supplier নাম *</label><input id="qName" class="input"></div><div class="field"><label>ফোন</label><input id="qPhone" class="input"></div><div class="field"><label>ঠিকানা</label><input id="qAddr" class="input"></div><button class="btn" onclick="savePurchaseSupplierQuick()">সেভ করুন</button>`);
}
function savePurchaseSupplierQuick(){
 const name=document.getElementById('qName').value.trim(); if(!name){toast('Supplier-এর নাম দিন');return}
 const x={id:uid('SUP'),name,phone:document.getElementById('qPhone').value,address:document.getElementById('qAddr').value,openingDue:0};
 db.suppliers.push(x);save();closeModal();render('purchase');setTimeout(()=>{const el=document.getElementById('purSupplier');if(el){el.value=x.id}},0);toast('Supplier যোগ হয়েছে');
}
function editPurchaseSupplier(){
 const el=document.getElementById('purSupplier'); const id=el?.value||''; if(!id){toast('আগে Supplier নির্বাচন করুন');return} window._returnToPurchaseAfterPartyEdit=true; openPartyForm('supplier',id);
}

function nextPurchasePreview(){return db.settings.invoicePrefix+"-"+String(db.counters.purchase).padStart(6,"0")}
function addPurchase(pid){const p=db.products.find(x=>x.id===pid);if(!p)return;let i=purchaseCart.find(x=>x.productId===pid);if(i)i.qty++;else purchaseCart.push({productId:p.id,name:p.name,cost:num(p.costPrice),qty:1});render("purchase")}
function chgPur(k,d){purchaseCart[k].qty=Math.max(1,purchaseCart[k].qty+d);render("purchase")}
function setPurQty(k,v){if(!purchaseCart[k])return;purchaseCart[k].qty=Math.max(1,Math.floor(num(v)||1));render("purchase")}
function setPurName(k,v){if(!purchaseCart[k])return;const name=String(v||"").trim();if(name)purchaseCart[k].name=name;render("purchase")}
function setPurCost(k,v){if(!purchaseCart[k])return;purchaseCart[k].cost=Math.max(0,num(v));render("purchase")}
function completePurchase(){
 if(savingPurchase)return;
 if(!purchaseCart.length){toast("আইটেম যোগ করুন");return}
 savingPurchase=true;const saveBtn=document.getElementById("completePurchaseBtn");if(saveBtn){saveBtn.disabled=true;saveBtn.textContent="⏳ ক্রয় সেভ হচ্ছে...";saveBtn.style.opacity=".7"}
 const total=purchaseCart.reduce((a,i)=>a+i.qty*i.cost,0),paid=Math.min(total,Math.max(0,num(document.getElementById("purPaid")?.value)));
 const s={id:uid("P"),invoice:document.getElementById("purBill").value||nextNo("purchase"),date:document.getElementById("purDate").value||today(),supplierId:document.getElementById("purSupplier")?.value||"",supplierName:db.suppliers.find(x=>x.id===document.getElementById("purSupplier")?.value)?.name||"",items:clone(purchaseCart),total,paid,due:total-paid,note:document.getElementById("purNote")?.value||""};
 db.purchases.push(s);purchaseCart.forEach(i=>{let p=db.products.find(x=>x.id===i.productId);if(!p){p={id:uid("PR"),name:i.name,barcode:"",category:"ক্রয় থেকে",unit:"pcs",reorder:0,costPrice:i.cost,salePrice:0,stock:0,description:""};db.products.push(p);i.productId=p.id}p.name=i.name;p.stock+=i.qty;p.costPrice=i.cost;addMove(p.id,i.qty,"PURCHASE",s.invoice)});s.items=clone(purchaseCart);save();purchaseCart=[];render("purchase");showInvoice(s,"purchase");savingPurchase=false;toast("✓ ক্রয় সফলভাবে সেভ হয়েছে");
}

function productNameCompare(a,b,mode){
 const A=String(a.name||""),B=String(b.name||"");
 if(mode==="az") return A.localeCompare(B,"en",{sensitivity:"base",numeric:true});
 if(mode==="za") return B.localeCompare(A,"en",{sensitivity:"base",numeric:true});
 if(mode==="bn") return A.localeCompare(B,"bn",{sensitivity:"base",numeric:true});
 if(mode==="nb") return B.localeCompare(A,"bn",{sensitivity:"base",numeric:true});
 return 0;
}
function productsPage(){
 document.getElementById("products").innerHTML=`<div class="title"><div><h1>পণ্য / স্টক</h1><div class="sub">নাম অনুযায়ী A–Z, Z–A অথবা অ–য় ক্রমে সাজানো যাবে</div></div><button class="btn" onclick="openProductForm()">＋ নতুন পণ্য</button></div>
 <div class="card product-shell"><div style="display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap"><b>পণ্য তালিকার Background</b><div class="theme-panel-inline">${[["auto","থিম"],["white","সাদা"],["gray","ধূসর"],["black","কালো"],["purple","পার্পল"],["blue","নীল"],["green","সবুজ"]].map(x=>`<button class="theme-chip ${db.settings.productBg===x[0]?'active':''}" onclick="applyProductBg('${x[0]}');productsPage()">${x[1]}</button>`).join('')}</div></div><div class="toolbar"><input id="prodSearch" class="input search" placeholder="নাম / Barcode খুঁজুন"><select id="catFilter" class="select search"><option value="">সব Category</option>${[...new Set(db.products.map(p=>p.category).filter(Boolean))].map(x=>`<option value="${esc(x)}">${esc(x)}</option>`).join("")}</select><select id="prodSort" class="select search"><option value="az">English A–Z</option><option value="za">English Z–A</option><option value="bn">বাংলা অ–য়</option><option value="nb">বাংলা য়–অ</option></select><button class="btn secondary" onclick="exportProducts()">CSV Export</button></div>
 <div class="tablewrap section"><table class="table"><thead><tr><th>পণ্য</th><th>Barcode</th><th>Category</th><th>ক্রয়মূল্য</th><th>বিক্রয়মূল্য</th><th>স্টক</th><th>স্টক মূল্য</th><th>Action</th></tr></thead><tbody id="prodBody"></tbody></table></div><div id="prodMobile" class="section"></div></div>`;
 const draw=()=>{
   const q=(document.getElementById('prodSearch').value||'').trim().toLowerCase(), cat=document.getElementById('catFilter').value||'', sort=document.getElementById('prodSort').value||'az';
   const arr=db.products.filter(p=>(!q||String(p.name||'').toLowerCase().includes(q)||String(p.barcode||'').toLowerCase().includes(q))&&(!cat||p.category===cat)).slice().sort((a,b)=>productNameCompare(a,b,sort));
   document.getElementById('prodBody').innerHTML=arr.map(p=>`<tr><td><b class="clickable" onclick="openProductDetail('${p.id}')">${esc(p.name)}</b></td><td>${esc(p.barcode||'—')}</td><td>${esc(p.category||'—')}</td><td>${money(p.costPrice)}</td><td>${money(p.salePrice)}</td><td><span class="pill ${p.stock<=Number(p.reorder??db.settings.lowStock)?'warn':'ok'}">${p.stock} ${esc(p.unit||'pcs')}</span></td><td>${money(p.stock*p.costPrice)}</td><td><div class="toolbar"><button class="btn sm secondary" onclick="editProduct('${p.id}')">Edit</button><button class="btn sm gray" onclick="manualProductBackup('${p.id}')">💾 Backup</button><button class="btn sm stock-zero" onclick="zeroProductStock('${p.id}')">স্টক 0</button><button class="btn sm danger-outline" onclick="deleteProduct('${p.id}')">Delete</button></div></td></tr>`).join('')||`<tr><td colspan="8" class="empty">কোনো পণ্য পাওয়া যায়নি। উপরের “＋ নতুন পণ্য” চাপুন।</td></tr>`;
   document.getElementById('prodMobile').innerHTML=arr.map(p=>`<div class="card clickable" style="margin-bottom:10px" onclick="openProductDetail('${p.id}')"><div style="display:flex;justify-content:space-between;gap:10px"><div><b>${esc(p.name)}</b><div class="sub">${esc(p.barcode||'Barcode নেই')} · ${esc(p.category||'Category নেই')}</div></div><span class="pill ${p.stock<=Number(p.reorder??db.settings.lowStock)?'warn':'ok'}">স্টক ${p.stock}</span></div><div class="totalline"><span>ক্রয়মূল্য</span><b>${money(p.costPrice)}</b></div><div class="totalline"><span>বিক্রয়মূল্য</span><b>${money(p.salePrice)}</b></div><div class="toolbar"><button class="btn sm secondary" onclick="event.stopPropagation();editProduct('${p.id}')">Edit</button><button class="btn sm gray" onclick="event.stopPropagation();manualProductBackup('${p.id}')">💾 Backup</button><button class="btn sm stock-zero" onclick="event.stopPropagation();zeroProductStock('${p.id}')">স্টক 0</button><button class="btn sm danger-outline" onclick="event.stopPropagation();deleteProduct('${p.id}')">Delete</button></div></div>`).join('')||`<div class="empty">কোনো পণ্য পাওয়া যায়নি।</div>`;
 };
 ['prodSearch','catFilter','prodSort'].forEach(id=>document.getElementById(id).addEventListener('input',draw));
 document.getElementById('catFilter').addEventListener('change',draw);document.getElementById('prodSort').addEventListener('change',draw);draw();
}

function openProductDetail(id){const p=db.products.find(x=>x.id===id);if(!p){toast('পণ্য পাওয়া যায়নি');return}document.querySelectorAll('.page').forEach(x=>x.classList.remove('active'));document.getElementById('productDetail').classList.add('active');document.querySelectorAll('.nav').forEach(x=>x.classList.toggle('active',x.dataset.page==='products'));document.getElementById('side').classList.remove('open');
 const sold=db.sales.flatMap(s=>s.items.map(i=>({...i,date:s.date,invoice:s.invoice}))).filter(i=>i.productId===id);const bought=db.purchases.flatMap(s=>s.items.map(i=>({...i,date:s.date,invoice:s.invoice}))).filter(i=>i.productId===id);const moves=db.stockMoves.filter(m=>m.productId===id).slice().reverse().slice(0,20);const potential=p.stock*p.salePrice;const stockValue=p.stock*p.costPrice;const profitPer=p.salePrice-p.costPrice;
 document.getElementById('productDetail').innerHTML=`<div class="title"><div><button class="btn gray sm" onclick="page('products')">← পণ্য তালিকা</button><h1 style="margin-top:10px">${esc(p.name)}</h1><div class="sub">${esc(p.barcode||'Barcode নেই')} · ${esc(p.category||'কোনো Category নেই')}</div></div><div class="toolbar"><button class="btn secondary" onclick="openProductForm('${p.id}')">Edit</button><button class="btn gray" onclick="manualProductBackup('${p.id}')">💾 Backup</button><button class="btn stock-zero" onclick="zeroProductStock('${p.id}')">স্টক 0</button><button class="btn danger-outline" onclick="deleteProduct('${p.id}')">Delete</button><button class="btn" onclick="page('sale');setTimeout(()=>addSale('${p.id}'),0)">বিক্রি করুন</button></div></div>
 <div class="grid g4"><div class="card stat"><div class="label">বর্তমান স্টক</div><div class="value">${p.stock}</div><div class="small">${esc(p.unit||'pcs')}</div></div><div class="card stat"><div class="label">ক্রয়মূল্য</div><div class="value">${money(p.costPrice)}</div></div><div class="card stat"><div class="label">বিক্রয়মূল্য</div><div class="value">${money(p.salePrice)}</div></div><div class="card stat"><div class="label">প্রতি ইউনিট লাভ</div><div class="value">${money(profitPer)}</div></div></div>
 <div class="grid g3 section"><div class="card"><b>স্টক মূল্য</b><div class="stat value">${money(stockValue)}</div></div><div class="card"><b>সব বিক্রি করলে</b><div class="stat value">${money(potential)}</div></div><div class="card"><b>মোট বিক্রিত</b><div class="stat value">${sold.reduce((a,i)=>a+i.qty,0)}</div></div></div>
 <div class="grid g2 section"><div class="card"><h3>পণ্যের তথ্য</h3><div class="totalline"><span>Barcode</span><b>${esc(p.barcode||'—')}</b></div><div class="totalline"><span>Category</span><b>${esc(p.category||'—')}</b></div><div class="totalline"><span>Unit</span><b>${esc(p.unit||'pcs')}</b></div><div class="totalline"><span>Reorder Level</span><b>${p.reorder||db.settings.lowStock}</b></div><div class="totalline"><span>Supplier</span><b>${esc(db.suppliers.find(s=>s.id===p.supplierId)?.name||'—')}</b></div><div class="totalline"><span>বর্ণনা</span><b>${esc(p.description||'—')}</b></div></div><div class="card"><h3>সাম্প্রতিক Stock Movement</h3>${moves.map(m=>`<div class="totalline"><span>${esc(m.type)}<div class="sub">${new Date(m.date).toLocaleString('bn-BD')}</div></span><b>${m.qty>0?'+':''}${m.qty}</b></div>`).join('')||'<div class="empty">কোনো movement নেই</div>'}</div></div>
 <div class="card section"><h3>সাম্প্রতিক বিক্রি</h3><div class="tablewrap"><table class="table"><tr><th>Invoice</th><th>Date</th><th>Qty</th><th>Rate</th><th>Profit</th></tr>${sold.slice().reverse().slice(0,20).map(i=>`<tr><td>${esc(i.invoice)}</td><td>${i.date}</td><td>${i.qty}</td><td>${money(i.price)}</td><td>${money((i.price-i.cost)*i.qty)}</td></tr>`).join('')||'<tr><td colspan="5" class="empty">এখনও বিক্রি হয়নি</td></tr>'}</table></div></div>`;
}

function openProductForm(id=""){const p=db.products.find(x=>x.id===id)||{name:"",barcode:"",category:"",costPrice:0,salePrice:0,stock:0,reorder:5,unit:"pcs",supplierId:"",description:""};
 modal(`<div class="modalhead"><h2>${id?"পণ্য Edit":"নতুন পণ্য"}</h2><button class="close" onclick="closeModal()">×</button></div>
 <div class="formrow"><div class="field"><label>পণ্যের নাম *</label><input id="pfName" class="input" value="${esc(p.name)}"></div><div class="field"><label>Barcode</label><input id="pfBarcode" class="input" value="${esc(p.barcode||"")}"></div></div>
 <div class="formrow3"><div class="field"><label>Category</label><input id="pfCat" class="input" list="productCategorySuggestions" autocomplete="off" value="${esc(p.category||"")}">${categoryDatalist("productCategorySuggestions")}</div><div class="field"><label>Unit</label><select id="pfUnit" class="select">${["pcs","kg","g","ltr","box","packet","dozen"].map(x=>`<option ${p.unit===x?"selected":""}>${x}</option>`).join("")}</select></div><div class="field"><label>Reorder Level</label><input id="pfReorder" class="input" type="number" min="0" value="${p.reorder??5}"></div></div>
 <div class="formrow"><div class="field"><label>ক্রয়মূল্য *</label><input id="pfCost" class="input" type="number" min="0" step=".01" value="${p.costPrice}"></div><div class="field"><label>বিক্রয়মূল্য *</label><input id="pfSale" class="input" type="number" min="0" step=".01" value="${p.salePrice}"></div></div>
 ${id?`<div class="field"><label>বর্তমান স্টক</label><input id="pfStock" class="input" type="number" min="0" value="${p.stock}"></div>`:`<div class="field"><label>Opening Stock</label><input id="pfStock" class="input" type="number" min="0" value="0"></div>`}
 <div class="field"><label>বর্ণনা</label><textarea id="pfDesc" class="textarea">${esc(p.description||"")}</textarea></div>
 <button id="saveProductBtn" class="btn" onclick="saveProduct('${id}')">💾 সেভ করুন</button>`);
}
function saveProduct(id){
 if(savingProduct)return;
 const btn=document.getElementById("saveProductBtn");
 const name=document.getElementById("pfName").value.trim();if(!name){toast("পণ্যের নাম দিন");return}
 savingProduct=true;if(btn){btn.disabled=true;btn.textContent="⏳ সেভ হচ্ছে..."}
 const cost=num(document.getElementById("pfCost").value),sale=num(document.getElementById("pfSale").value),stock=Math.max(0,num(document.getElementById("pfStock").value));let p=db.products.find(x=>x.id===id);
 if(p){const old=p.stock;p.name=name;p.barcode=document.getElementById("pfBarcode").value.trim();p.category=document.getElementById("pfCat").value.trim();p.unit=document.getElementById("pfUnit").value;p.reorder=num(document.getElementById("pfReorder").value);p.costPrice=cost;p.salePrice=sale;p.stock=stock;p.description=document.getElementById("pfDesc").value;if(old!==stock)addMove(p.id,stock-old,"ADJUST","MANUAL")}
 else{p={id:uid("PR"),name,barcode:document.getElementById("pfBarcode").value.trim(),category:document.getElementById("pfCat").value.trim(),unit:document.getElementById("pfUnit").value,reorder:num(document.getElementById("pfReorder").value),costPrice:cost,salePrice:sale,stock,description:document.getElementById("pfDesc").value};db.products.push(p);if(stock)addMove(p.id,stock,"OPENING","OPENING")}
 save();closeModal();render("products");savingProduct=false;toast("✓ পণ্য সেভ হয়েছে");
}
function editProduct(id){openProductForm(id)}
function zeroProductStock(id){const p=db.products.find(x=>x.id===id);if(!p)return;if(!p.stock){toast("এই পণ্যের স্টক ইতিমধ্যে 0");return}if(confirm(`"${p.name}"-এর বর্তমান স্টক ${p.stock} থেকে 0 করে দেব?`)){makeSafetyBackup(`স্টক 0 করার আগের অবস্থা: ${p.name}`);const old=p.stock;p.stock=0;addMove(p.id,-old,"ADJUST","MANUAL","স্টক 0 করা হয়েছে");save();render("products");toast("স্টক 0 করা হয়েছে")}}
function deleteProduct(id){const p=db.products.find(x=>x.id===id);if(!p)return;const hasTx=db.sales.some(s=>s.items.some(i=>i.productId===id))||db.purchases.some(s=>s.items.some(i=>i.productId===id));const msg=hasTx?`"${p.name}"-এর আগের লেনদেন আছে। পণ্যটি তালিকা থেকে মুছে দিলে পুরোনো Invoice-এর নাম রাখা হবে, কিন্তু পণ্যটি আর স্টকে থাকবে না। মুছবেন?`:`"${p.name}" পণ্যটি সম্পূর্ণ মুছে ফেলবেন?`;if(confirm(msg)){makeSafetyBackup(`পণ্য Delete-এর আগের অবস্থা: ${p.name}`);db.sales.forEach(s=>{s.items.forEach(i=>{if(i.productId===id&&!i.name)i.name=p.name})});db.purchases.forEach(s=>{s.items.forEach(i=>{if(i.productId===id&&!i.name)i.name=p.name})});db.products=db.products.filter(x=>x.id!==id);save();render("products");toast("পণ্য মুছে ফেলা হয়েছে")}}
function exportProducts(){const rows=[["Name","Barcode","Category","Cost","Sale","Stock","Unit"],...db.products.map(p=>[p.name,p.barcode,p.category,p.costPrice,p.salePrice,p.stock,p.unit])];const csv=rows.map(r=>r.map(x=>`"${String(x??"").replace(/"/g,'""')}"`).join(",")).join("\n");const a=document.createElement("a");a.href=URL.createObjectURL(new Blob(["\ufeff"+csv],{type:"text/csv"}));a.download="products.csv";a.click()}

function openProductPicker(type){modal(`<div class="modalhead"><div><h2>পণ্য নির্বাচন</h2><div class="sub">নাম/Barcode খুঁজে Quantity সরাসরি লিখে যোগ করুন</div></div><button class="close" onclick="closeModal()">×</button></div><input id="pickSearch" class="input" placeholder="নাম / Barcode"><div id="pickList" class="section"></div>`);const draw=()=>{const q=document.getElementById("pickSearch").value.toLowerCase();document.getElementById("pickList").innerHTML=db.products.filter(p=>p.name.toLowerCase().includes(q)||String(p.barcode||"").includes(q)).map(p=>`<div class="card" style="padding:12px;margin:8px 0;display:flex;align-items:center;justify-content:space-between;gap:10px"><div style="min-width:0;flex:1"><b style="font-size:16px">${esc(p.name)}</b><div class="sub">${esc(p.barcode||"Barcode নেই")} · ${money(type==="sale"?p.salePrice:p.costPrice)} · স্টক ${p.stock}</div></div><div style="display:flex;align-items:center;gap:7px"><input id="pickq_${p.id}" class="input" style="width:82px" type="number" min="1" value="1"><button class="btn sm" onclick="addPickedProduct('${p.id}','${type}')">যোগ</button></div></div>`).join("")||`<div class="empty">পণ্য পাওয়া যায়নি</div>`};draw();document.getElementById("pickSearch").oninput=draw}
function addPickedProduct(pid,type){const q=Math.max(1,Math.floor(num(document.getElementById("pickq_"+pid)?.value)||1));const p=db.products.find(x=>x.id===pid);if(!p)return;if(type==="sale"){if(q>p.stock){toast("স্টকের চেয়ে বেশি Quantity দেওয়া যাবে না");return}for(let n=0;n<q;n++)addSale(pid)}else{let i=purchaseCart.find(x=>x.productId===pid);if(i)i.qty+=q;else purchaseCart.push({productId:p.id,name:p.name,cost:num(p.costPrice),qty:q});render("purchase")}closeModal()}
function scanBarcode(type){if(!("BarcodeDetector" in window)){toast("এই browser-এ Camera Barcode নেই। Scanner keyboard দিয়ে barcode input-এ scan করুন");return}modal(`<div class="modalhead"><h2>Camera Barcode Scanner</h2><button class="close" onclick="closeModal()">×</button></div><video id="video" style="width:100%;border-radius:12px" autoplay playsinline></video><div class="sub">Barcode ক্যামেরার সামনে ধরুন</div>`);navigator.mediaDevices?.getUserMedia({video:{facingMode:"environment"}}).then(stream=>{const v=document.getElementById("video");v.srcObject=stream;const det=new BarcodeDetector();const loop=async()=>{if(!document.getElementById("video")){stream.getTracks().forEach(t=>t.stop());return}try{const r=await det.detect(v);if(r[0]){quickScanValue(r[0].rawValue);closeModal();stream.getTracks().forEach(t=>t.stop());return}}catch(_){}requestAnimationFrame(loop)};loop()}).catch(()=>toast("Camera permission দিন"))}

function quickParty(type){modal(`<div class="modalhead"><h2>নতুন ${type==="customer"?"Customer":"Supplier"}</h2><button class="close" onclick="closeModal()">×</button></div><div class="field"><label>নাম *</label><input id="qName" class="input"></div><div class="field"><label>ফোন</label><input id="qPhone" class="input"></div><div class="field"><label>ঠিকানা</label><input id="qAddr" class="input"></div><button class="btn" onclick="savePartyQuick('${type}')">সেভ</button>`)}
function savePartyQuick(type){const name=document.getElementById("qName").value.trim();if(!name){toast("নাম দিন");return}const x={id:uid(type==="customer"?"C":"SUP"),name,phone:document.getElementById("qPhone").value,address:document.getElementById("qAddr").value};db[type==="customer"?"customers":"suppliers"].push(x);save();closeModal();render(document.querySelector(".page.active").id);toast("Party সেভ হয়েছে")}

function partiesPage(){document.getElementById("parties").innerHTML=`<div class="title"><div><h1>Customer / Supplier</h1><div class="sub">বাকি, ফোন, ঠিকানা ও লেনদেন</div></div><div class="toolbar"><button class="btn" onclick="openPartyForm('customer')">＋ Customer</button><button class="btn secondary" onclick="openPartyForm('supplier')">＋ Supplier</button></div></div><div class="grid g2"><div class="card"><div class="title"><h3>Customers (${db.customers.length})</h3><button class="btn sm danger-outline" onclick="deleteAllParties('customer')">সব Customer Delete</button></div>${partyTable("customer")}</div><div class="card"><div class="title"><h3>Suppliers (${db.suppliers.length})</h3><button class="btn sm danger-outline" onclick="deleteAllParties('supplier')">সব Supplier Delete</button></div>${partyTable("supplier")}</div></div>`}
function partyTable(type){const a=type==="customer"?db.customers:db.suppliers;return `<div class="tablewrap"><table class="table"><tr><th>নাম</th><th>ফোন</th><th>বাকি</th><th></th></tr>${a.map(x=>`<tr><td>${esc(x.name)}</td><td>${esc(x.phone||"")}</td><td>${money(partyDue(type,x.id))}</td><td><div class="toolbar"><button class="btn sm secondary" onclick="openPartyForm('${type}','${x.id}')">Edit</button><button class="btn sm gray" onclick="manualPartyBackup('${type}','${x.id}')">💾 Backup</button><button class="btn sm party-danger" onclick="deleteParty('${type}','${x.id}')">Delete</button></div></td></tr>`).join("")||`<tr><td colspan="4" class="empty">কেউ নেই</td></tr>`}</table></div>`}
function openPartyForm(type,id=""){const arr=type==="customer"?db.customers:db.suppliers,p=arr.find(x=>x.id===id)||{name:"",phone:"",address:"",openingDue:0};modal(`<div class="modalhead"><h2>${id?"Edit":"নতুন"} ${type==="customer"?"Customer":"Supplier"}</h2><button class="close" onclick="closeModal()">×</button></div><div class="field"><label>নাম *</label><input id="paName" class="input" value="${esc(p.name)}"></div><div class="formrow"><div class="field"><label>ফোন</label><input id="paPhone" class="input" value="${esc(p.phone||"")}"></div><div class="field"><label>Opening Due</label><input id="paDue" class="input" type="number" min="0" value="${p.openingDue||0}"></div></div><div class="field"><label>ঠিকানা</label><textarea id="paAddr" class="textarea">${esc(p.address||"")}</textarea></div><button class="btn" onclick="saveParty('${type}','${id}')">সেভ করুন</button>`)}
function saveParty(type,id){const arr=type==="customer"?db.customers:db.suppliers,name=document.getElementById("paName").value.trim();if(!name){toast("নাম দিন");return}let p=arr.find(x=>x.id===id);if(!p){p={id:uid(type==="customer"?"C":"SUP")};arr.push(p)}p.name=name;p.phone=document.getElementById("paPhone").value;p.address=document.getElementById("paAddr").value;p.openingDue=num(document.getElementById("paDue").value);save();closeModal();if(window._returnToPurchaseAfterPartyEdit&&type==="supplier"){window._returnToPurchaseAfterPartyEdit=false;render("purchase");setTimeout(()=>{const el=document.getElementById("purSupplier");if(el)el.value=p.id},0)}else{render("parties")}}

function deleteAllParties(type){
 const key=type==="customer"?"customers":"suppliers", arr=db[key];
 if(!arr.length){toast("কোনো Party নেই");return}
 const label=type==="customer"?"সব Customer":"সব Supplier";
 if(!confirm(`${label} তালিকা থেকে মুছে ফেলবেন? পুরোনো Invoice/লেনদেনের নাম রাখা হবে। আগে Safety Backup নেওয়া হবে।`)) return;
 makeSafetyBackup(`${label} সব Delete-এর আগের অবস্থা`);
 if(type==="customer") db.sales.forEach(s=>{if(s.customerId){const x=arr.find(p=>p.id===s.customerId);if(x)s.customerName=x.name;s.customerId=""}});
 else db.purchases.forEach(s=>{if(s.supplierId){const x=arr.find(p=>p.id===s.supplierId);if(x)s.supplierName=x.name;s.supplierId=""}});
 db.payments.forEach(x=>{if((type==="customer"&&x.type==="customer")||(type==="supplier"&&x.type==="supplier")){const party=arr.find(p=>p.id===x.partyId);if(party)x.partyName=party.name;x.partyId=""}});
 db[key]=[];save();render("parties");toast(`${label} Delete হয়েছে`);
}

function deleteParty(type,id){const arr=type==="customer"?db.customers:db.suppliers,p=arr.find(x=>x.id===id);if(!p)return;const relatedSales=db.sales.filter(s=>s.customerId===id).length,relatedPurchases=db.purchases.filter(s=>s.supplierId===id).length,relatedPayments=db.payments.filter(x=>x.partyId===id).length;const total=relatedSales+relatedPurchases+relatedPayments;const msg=total?`"${p.name}"-এর ${total}টি পুরোনো হিসাব/লেনদেন আছে। Delete করলে পুরোনো Invoice-এ নাম রাখব, কিন্তু Party তালিকা থেকে সরবে। চালিয়ে যাবেন?`:`"${p.name}"-কে Party তালিকা থেকে মুছে ফেলবেন?`;if(!confirm(msg))return;makeSafetyBackup(`Party Delete-এর আগের অবস্থা: ${p.name}`);db.sales.forEach(s=>{if(s.customerId===id){s.customerName=p.name;s.customerId=""}});db.purchases.forEach(s=>{if(s.supplierId===id){s.supplierName=p.name;s.supplierId=""}});db.payments.forEach(x=>{if(x.partyId===id){x.partyName=p.name;x.partyId=""}});const key=type==="customer"?"customers":"suppliers";db[key]=db[key].filter(x=>x.id!==id);save();render("parties");toast("Party মুছে ফেলা হয়েছে")}
function duesPage(){const customers=db.customers.map(x=>({...x,type:"customer",due:partyDue("customer",x.id)})).filter(x=>x.due>0),suppliers=db.suppliers.map(x=>({...x,type:"supplier",due:partyDue("supplier",x.id)})).filter(x=>x.due>0);document.getElementById("dues").innerHTML=`<div class="title"><div><h1>বাকি হিসাব</h1><div class="sub">Customer-এর পাওনা ও Supplier-এর দেনা</div></div><button class="btn" onclick="openPaymentForm()">＋ বাকি আদায়/পরিশোধ</button></div><div class="grid g2"><div class="card"><h3>Customer থেকে পাওনা</h3>${dueTable(customers)}</div><div class="card"><h3>Supplier-কে দেনা</h3>${dueTable(suppliers)}</div></div><div class="card section"><h3>সাম্প্রতিক পেমেন্ট</h3>${db.payments.slice().reverse().slice(0,20).map(x=>`<div class="totalline"><span>${esc(x.partyName)} · ${x.date}</span><b>${money(x.amount)}</b></div>`).join("")||'<div class="empty">কোনো payment নেই</div>'}</div>`}
function dueTable(a){return `<div class="tablewrap"><table class="table"><tr><th>Party</th><th>ফোন</th><th>বাকি</th><th></th></tr>${a.map(x=>`<tr><td>${esc(x.name)}</td><td>${esc(x.phone||"")}</td><td><span class="pill bad">${money(x.due)}</span></td><td><button class="btn sm" onclick="openPaymentForm('${x.type}','${x.id}')">${x.type==="customer"?"আদায়":"পরিশোধ"}</button></td></tr>`).join("")||`<tr><td colspan="4" class="empty">কোনো বাকি নেই</td></tr>`}</table></div>`}
function openPaymentForm(type="",id=""){modal(`<div class="modalhead"><h2>বাকি ${type==="supplier"?"পরিশোধ":"আদায়"}</h2><button class="close" onclick="closeModal()">×</button></div><div class="field"><label>ধরন</label><select id="payType" class="select" onchange="paymentPartyRefresh()"><option value="customer" ${type!=="supplier"?"selected":""}>Customer থেকে আদায়</option><option value="supplier" ${type==="supplier"?"selected":""}>Supplier-কে পরিশোধ</option></select></div><div class="field"><label>Party</label><select id="payParty" class="select">${partyOptions(type==="supplier"?"supplier":"customer",id)}</select></div><div class="formrow"><div class="field"><label>Amount</label><input id="payAmt" class="input" type="number" min="0"></div><div class="field"><label>Method</label><select id="payMethod" class="select"><option>Cash</option><option>Bank</option><option>Mobile Banking</option><option>Card</option></select></div></div><div class="field"><label>Note</label><input id="payNote" class="input"></div><button class="btn" onclick="savePayment()">সেভ করুন</button>`)}
function paymentPartyRefresh(){const t=document.getElementById("payType").value;document.getElementById("payParty").innerHTML=partyOptions(t)}
function savePayment(){const type=document.getElementById("payType").value,id=document.getElementById("payParty").value,amt=num(document.getElementById("payAmt").value);if(!id||amt<=0){toast("Party ও Amount দিন");return}const arr=type==="customer"?db.customers:db.suppliers,p=arr.find(x=>x.id===id);db.payments.push({id:uid("PAY"),type,partyId:id,partyName:p.name,amount:amt,method:document.getElementById("payMethod").value,note:document.getElementById("payNote").value,date:today()});save();closeModal();render("dues");toast("Payment সেভ হয়েছে")}

function expensesPage(){const total=db.expenses.filter(x=>x.date===today()).reduce((a,x)=>a+x.amount,0);document.getElementById("expenses").innerHTML=`<div class="title"><div><h1>খরচ</h1><div class="sub">দৈনিক/মাসিক লাভের রিপোর্টে খরচ যাবে</div></div><button class="btn" onclick="openExpenseForm()">＋ খরচ যোগ করুন</button></div><div class="card stat"><div class="label">আজকের খরচ</div><div class="value">${money(total)}</div></div><div class="card section">${db.expenses.slice().reverse().map(x=>`<div class="totalline"><span>${esc(x.category)} · ${esc(x.note||"")} · ${x.date}</span><b>${money(x.amount)}</b></div>`).join("")||'<div class="empty">কোনো খরচ নেই</div>'}</div>`}
function openExpenseForm(){modal(`<div class="modalhead"><h2>খরচ যোগ করুন</h2><button class="close" onclick="closeModal()">×</button></div><div class="formrow"><div class="field"><label>Category</label><select id="exCat" class="select"><option>দোকান ভাড়া</option><option>বিদ্যুৎ</option><option>বেতন</option><option>পরিবহন</option><option>প্যাকেজিং</option><option>অন্যান্য</option></select></div><div class="field"><label>Amount</label><input id="exAmt" class="input" type="number" min="0"></div></div><div class="field"><label>Date</label><input id="exDate" class="input" type="date" value="${today()}"></div><div class="field"><label>Note</label><textarea id="exNote" class="textarea"></textarea></div><button class="btn" onclick="saveExpense()">সেভ করুন</button>`)}
function saveExpense(){const amount=num(document.getElementById("exAmt").value);if(amount<=0){toast("Amount দিন");return}db.expenses.push({id:uid("EX"),category:document.getElementById("exCat").value,amount,date:document.getElementById("exDate").value,note:document.getElementById("exNote").value});save();closeModal();render("expenses")}

function returnsPage(){document.getElementById("returns").innerHTML=`<div class="title"><div><h1>Sales / Purchase Return</h1><div class="sub">পুরনো Invoice থেকে Return করে Stock ও হিসাব ঠিক করুন</div></div></div><div class="grid g2"><div class="card"><h3>বিক্রয় রিটার্ন</h3><div class="field"><label>Invoice নম্বর</label><input id="retSaleNo" class="input" placeholder="INV-001001"></div><button class="btn" onclick="findReturn('sale')">Invoice খুঁজুন</button></div><div class="card"><h3>ক্রয় রিটার্ন</h3><div class="field"><label>বিল নম্বর</label><input id="retPurNo" class="input"></div><button class="btn" onclick="findReturn('purchase')">বিল খুঁজুন</button></div></div><div id="returnResult" class="section"></div>`}
function findReturn(type){const no=document.getElementById(type==="sale"?"retSaleNo":"retPurNo").value.trim();const arr=type==="sale"?db.sales:db.purchases,s=arr.find(x=>x.invoice===no);if(!s){toast("Invoice পাওয়া যায়নি");return}document.getElementById("returnResult").innerHTML=`<div class="card"><h3>${esc(s.invoice)} · ${s.date}</h3>${s.items.map((i,k)=>`<div class="cartrow"><div>${esc(i.name)}<div class="sub">মূল Qty ${i.qty}</div></div><input id="rq${k}" class="input" type="number" min="0" max="${i.qty}" value="${i.qty}"><div>${money(i.price)}</div><button class="btn danger sm" onclick="doReturn('${type}','${s.id}',${k})">Return</button></div>`).join("")}</div>`}
function doReturn(type,id,k){const arr=type==="sale"?db.sales:db.purchases,s=arr.find(x=>x.id===id),i=s.items[k],q=num(document.getElementById("rq"+k).value);if(q<=0||q>i.qty){toast("সঠিক Qty দিন");return}const already=db.returns.filter(r=>r.refId===id&&r.itemIndex===k).reduce((a,r)=>a+num(r.qty),0);if(already+q>num(i.qty)){toast(`সর্বোচ্চ ${Math.max(0,num(i.qty)-already)} Qty return করা যাবে`);return}const r={id:uid("RET"),invoice:nextNo("return"),date:today(),type,refId:id,itemIndex:k,productId:i.productId,qty:q,amount:q*i.price};db.returns.push(r);const p=db.products.find(x=>x.id===i.productId);if(p){p.stock+=type==="sale"?q:-q;addMove(p.id,type==="sale"?q:-q,type==="sale"?"SALE_RETURN":"PURCHASE_RETURN",r.invoice)}save();render("returns");toast("Return সম্পন্ন হয়েছে")}

function dateInRange(date,from,to){return (!from||date>=from)&&(!to||date<=to)}
function rangeReport(){
 const from=document.getElementById("reportFrom").value,to=document.getElementById("reportTo").value;if(!from||!to||from>to){toast("সঠিক তারিখের রেঞ্জ দিন");return}renderRangeReport(from,to);
}
function renderRangeReport(from,to){
 const sales=db.sales.filter(x=>!x.cancelled&&dateInRange(x.date,from,to)),ex=db.expenses.filter(x=>dateInRange(x.date,from,to));
 const saleReturns=db.returns.filter(r=>r.type==="sale"&&dateInRange(r.date,from,to)), revenue=sales.reduce((a,s)=>a+num(s.total),0)-saleReturns.reduce((a,r)=>a+num(r.amount),0),cogs=sales.reduce((a,s)=>a+s.items.reduce((q,i)=>q+num(i.qty)*num(i.cost),0),0)-saleReturns.reduce((a,r)=>{const s=sales.find(x=>x.id===r.refId),i=s?.items?.[r.itemIndex];return a+(i?num(r.qty)*num(i.cost):0)},0),expense=ex.reduce((a,x)=>a+num(x.amount),0),gross=revenue-cogs,net=gross-expense;
 document.getElementById("rangeResult").innerHTML=`<div class="grid g4"><div class="card stat"><div class="label">মোট বিক্রি</div><div class="value">${money(revenue)}</div></div><div class="card stat"><div class="label">পণ্যের খরচ (COGS)</div><div class="value">${money(cogs)}</div></div><div class="card stat"><div class="label">মোট লাভ</div><div class="value">${money(gross)}</div></div><div class="card stat"><div class="label">খরচ বাদে লাভ</div><div class="value">${money(net)}</div></div></div><div class="card section"><h3>${from} → ${to}</h3><div class="totalline"><span>বিক্রয় Invoice</span><b>${sales.length.toLocaleString('bn-BD')} টি</b></div><div class="totalline"><span>মোট বিক্রি</span><b>${money(revenue)}</b></div><div class="totalline"><span>মোট লাভ (Sales − Cost)</span><b>${money(gross)}</b></div><div class="totalline"><span>দোকানের খরচ</span><b>${money(expense)}</b></div><div class="totalline grand"><span>নিট লাভ</span><b>${money(net)}</b></div></div>`;
}
function reportsPage(){
 const sales=db.sales.filter(x=>!x.cancelled),purs=db.purchases.filter(x=>!x.cancelled),ex=db.expenses;
 const saleReturns=db.returns.filter(r=>r.type==="sale"); const purchaseReturns=db.returns.filter(r=>r.type==="purchase"); const revenue=sales.reduce((a,s)=>a+s.total,0)-saleReturns.reduce((a,r)=>a+num(r.amount),0),cogs=sales.reduce((a,s)=>a+s.items.reduce((q,i)=>q+num(i.qty)*num(i.cost),0),0)-saleReturns.reduce((a,r)=>{const s=sales.find(x=>x.id===r.refId),i=s?.items?.[r.itemIndex];return a+(i?num(r.qty)*num(i.cost):0)},0),expense=ex.reduce((a,x)=>a+x.amount,0),net=revenue-cogs-expense;
 const now=new Date(),defaultFrom=new Date(now.getFullYear(),now.getMonth(),1).toISOString().slice(0,10),defaultTo=today();
 const months=[...Array(6)].map((_,i)=>{const d=new Date();d.setMonth(d.getMonth()-5+i);const m=d.toISOString().slice(0,7);return {m,s:sales.filter(x=>x.date.startsWith(m)).reduce((a,x)=>a+x.total,0)}})
 document.getElementById("reports").innerHTML=`<div class="title"><div><h1>রিপোর্ট</h1><div class="sub">যেকোনো তারিখ থেকে যেকোনো তারিখ পর্যন্ত বিক্রি ও লাভ দেখুন</div></div><button class="btn secondary" onclick="printReport()">🖨 Print</button></div>
 <div class="card section"><h3>📅 তারিখ অনুযায়ী বিক্রি ও লাভ</h3><div class="formrow"><div class="field"><label>শুরুর তারিখ</label><input id="reportFrom" class="input" type="date" value="${defaultFrom}"></div><div class="field"><label>শেষ তারিখ</label><input id="reportTo" class="input" type="date" value="${defaultTo}"></div></div><div class="toolbar"><button class="btn" onclick="rangeReport()">রিপোর্ট দেখুন</button><button class="btn gray" onclick="document.getElementById('reportFrom').value='${defaultFrom}';document.getElementById('reportTo').value='${defaultTo}';rangeReport()">এই মাস</button></div><div id="rangeResult" class="section"></div></div>
 <div class="grid g4"><div class="card stat"><div class="label">মোট বিক্রয়</div><div class="value">${money(revenue)}</div></div><div class="card stat"><div class="label">মোট ক্রয়</div><div class="value">${money(purs.reduce((a,x)=>a+x.total,0))}</div></div><div class="card stat"><div class="label">Gross Profit</div><div class="value">${money(revenue-cogs)}</div></div><div class="card stat"><div class="label">Net Profit</div><div class="value">${money(net)}</div></div></div>
 <div class="grid g2 section"><div class="card"><h3>শেষ ৬ মাসের বিক্রয়</h3><div class="chart">${months.map(x=>`<div style="flex:1;height:100%;display:flex;flex-direction:column;justify-content:end"><div class="bar" style="height:${Math.max(5,Math.round(x.s/Math.max(1,...months.map(z=>z.s))*150))}px"></div><div class="barlabel">${x.m.slice(5)}</div></div>`).join("")}</div></div>
 <div class="card"><h3>লাভ-ক্ষতির সারাংশ</h3><div class="totalline"><span>Sales</span><b>${money(revenue)}</b></div><div class="totalline"><span>COGS</span><b>${money(cogs)}</b></div><div class="totalline"><span>Gross Profit</span><b>${money(revenue-cogs)}</b></div><div class="totalline"><span>Expense</span><b>${money(expense)}</b></div><div class="totalline grand"><span>Net Profit</span><b>${money(net)}</b></div></div></div>
 <div class="card section"><h3>Stock Valuation</h3><div class="tablewrap"><table class="table"><tr><th>পণ্য</th><th>Qty</th><th>Cost</th><th>Stock Value</th><th>Potential Sales</th></tr>${db.products.slice().sort((a,b)=>productNameCompare(a,b,'bn')).map(p=>`<tr><td>${esc(p.name)}</td><td>${p.stock}</td><td>${money(p.costPrice)}</td><td>${money(p.stock*p.costPrice)}</td><td>${money(p.stock*p.salePrice)}</td></tr>`).join("")||'<tr><td colspan="5" class="empty">কোনো পণ্য নেই</td></tr>'}</table></div></div>`;
 rangeReport();
}
function printReport(){window.print()}


async function sha256(text){try{if(globalThis.crypto?.subtle){const data=new TextEncoder().encode(text);const hash=await crypto.subtle.digest("SHA-256",data);return Array.from(new Uint8Array(hash)).map(b=>b.toString(16).padStart(2,"0")).join("")}}catch(_){} let h1=2166136261,h2=16777619; for(let i=0;i<text.length;i++){const c=text.charCodeAt(i);h1=Math.imul(h1^c,16777619);h2=Math.imul(h2^((c+i)&255),2246822519)} return (h1>>>0).toString(16).padStart(8,'0')+(h2>>>0).toString(16).padStart(8,'0')+text.length.toString(16).padStart(4,'0')}
let patternBuffer=[];
function lockOverlay(){
  if(db.settings.securityMode==="none")return;
  document.getElementById("lockScreen")?.remove();
  const box=document.createElement("div");box.id="lockScreen";box.style.cssText="position:fixed;inset:0;background:linear-gradient(135deg,#5d4be8,#7c63ff);z-index:9999;color:#fff;display:flex;align-items:center;justify-content:center;padding:24px";
  box.innerHTML=`<div style="width:min(390px,100%);text-align:center"><div style="font-size:54px">🔐</div><h2 style="margin:8px 0">Business360 লক করা আছে</h2><div style="opacity:.85;margin-bottom:18px">${db.settings.securityMode==="pin"?"PIN কোড দিন":"প্যাটার্ন দিন"}</div>${db.settings.securityMode==="pin"?`<input id="unlockPin" inputmode="numeric" type="password" maxlength="6" style="width:100%;padding:15px;border:0;border-radius:14px;font-size:24px;text-align:center;letter-spacing:8px"><button class="btn" style="width:100%;margin-top:12px;background:#fff;color:#5d4be8" onclick="unlockPin()">আনলক</button>`:`<div id="patternDots" style="display:grid;grid-template-columns:repeat(3,70px);gap:18px;justify-content:center;margin:15px 0"></div><button class="btn" style="width:100%;margin-top:12px;background:#fff;color:#5d4be8" onclick="unlockPattern()">প্যাটার্ন যাচাই</button>`}<div id="lockMsg" style="margin-top:12px;color:#ffe3e3"></div></div>`;
  document.body.appendChild(box);
  if(db.settings.securityMode==="pattern"){const d=box.querySelector('#patternDots');for(let i=1;i<=9;i++){const b=document.createElement('button');b.textContent=i;b.dataset.n=i;b.style.cssText="width:70px;height:70px;border-radius:50%;border:0;background:#ffffff25;color:#fff;font-size:22px";b.onclick=()=>{if(!patternBuffer.includes(i)){patternBuffer.push(i);b.style.background="#fff";b.style.color="#5d4be8"}};d.appendChild(b)}}
}
async function unlockPin(){const v=document.getElementById('unlockPin')?.value||'';const h=await sha256(v);if(h===db.settings.pinHash){document.getElementById('lockScreen')?.remove()}else{document.getElementById('lockMsg').textContent='PIN সঠিক নয়';document.getElementById('unlockPin').value=''}}
async function unlockPattern(){const v=patternBuffer.join('-'),h=await sha256(v);if(h===db.settings.patternHash){document.getElementById('lockScreen')?.remove();patternBuffer=[]}else{document.getElementById('lockMsg').textContent='প্যাটার্ন সঠিক নয়';patternBuffer=[];document.querySelectorAll('#patternDots button').forEach(b=>{b.style.background='#ffffff25';b.style.color='#fff'})}}
function securityModal(){modal(`<div class="modalhead"><h2>🔐 PIN / Pattern Lock</h2><button class="close" onclick="closeModal()">✕</button></div><div class="notice">অ্যাপ খুললে আগে লক চাইবে। PIN বা 3×3 Pattern—যেকোনো একটি ব্যবহার করুন।</div><div class="toolbar" style="margin-top:14px"><button class="btn" onclick="setupPin()">PIN সেট করুন</button><button class="btn secondary" onclick="setupPattern()">Pattern সেট করুন</button><button class="btn danger" onclick="disableLock()">লক বন্ধ</button></div>`)}
async function setupPin(){modal(`<div class="modalhead"><h2>PIN সেট করুন</h2><button class="close" onclick="closeModal()">✕</button></div><div class="field"><label>৪–৬ সংখ্যার PIN</label><input id="newPin" class="input" inputmode="numeric" type="password" maxlength="6" placeholder="যেমন 2580"></div><div class="field"><label>আবার PIN দিন</label><input id="newPin2" class="input" inputmode="numeric" type="password" maxlength="6"></div><button class="btn" onclick="savePin()">PIN সংরক্ষণ</button>`)}
async function savePin(){const a=document.getElementById('newPin').value,b=document.getElementById('newPin2').value;if(!/^\d{4,6}$/.test(a)||a!==b){toast('৪–৬ সংখ্যার একই PIN দিন');return}db.settings.securityMode='pin';db.settings.pinHash=await sha256(a);db.settings.patternHash='';save();closeModal();toast('PIN Lock চালু হয়েছে')}
async function setupPattern(){modal(`<div class="modalhead"><h2>Pattern সেট করুন</h2><button class="close" onclick="closeModal()">✕</button></div><div class="sub">নিচের 1–9 বোতামে অন্তত 4টি পয়েন্ট ক্রমে চাপুন।</div><div id="setupPatternDots" style="display:grid;grid-template-columns:repeat(3,60px);gap:12px;justify-content:center;margin:18px 0"></div><div id="patternSeq" class="notice center">কোনো পয়েন্ট নির্বাচন হয়নি</div><button class="btn" style="margin-top:12px" onclick="savePattern()">Pattern সংরক্ষণ</button>`);patternBuffer=[];const d=document.getElementById('setupPatternDots');for(let i=1;i<=9;i++){const b=document.createElement('button');b.textContent=i;b.dataset.n=i;b.style.cssText="width:60px;height:60px;border-radius:50%;border:1px solid #ddd;background:#f3f1ff;color:#5d4be8;font-size:20px";b.onclick=()=>{if(!patternBuffer.includes(i)){patternBuffer.push(i);b.style.background='#5d4be8';b.style.color='#fff';document.getElementById('patternSeq').textContent=patternBuffer.join(' • ')}};d.appendChild(b)}}
async function savePattern(){if(patternBuffer.length<4){toast('কমপক্ষে ৪টি পয়েন্ট দিন');return}db.settings.securityMode='pattern';db.settings.patternHash=await sha256(patternBuffer.join('-'));db.settings.pinHash='';save();patternBuffer=[];closeModal();toast('Pattern Lock চালু হয়েছে')}
function disableLock(){db.settings.securityMode='none';db.settings.pinHash='';db.settings.patternHash='';save();closeModal();toast('লক বন্ধ হয়েছে')}
function settingsPage(){document.getElementById("settings").innerHTML=`<div class="title"><div><h1>সেটিংস</h1><div class="sub">দোকানের তথ্য, Background থিম, লোগো, Lock ও Backup</div></div><button class="btn" onclick="openThemePicker()">🎨 থিম পরিবর্তন</button></div>
<div class="card"><h3>📱 Home Screen / App</h3><div class="notice">Chrome-এ HTTPS লিংক খুলে “Add to Home screen / Install app” দিলে Home Screen-এ Business360 অ্যাপের মতো থাকবে। এই ব্রাউজার থেকে সরাসরি ZIP/HTML খুললে Install অপশন আসবে না।</div><button class="btn" style="margin-top:10px" onclick="installApp()">⌂ Home Screen-এ নিন</button></div><div class="card section"><h3>🎨 Background / থিম পরিবর্তন</h3><div class="theme-grid">
<button class="theme-btn ${db.settings.theme==='purple'?'active':''}" onclick="applyTheme('purple');settingsPage()"><div class="theme-swatch" style="background:linear-gradient(135deg,#6c57f5,#8b5cf6)"></div>পার্পল</button>
<button class="theme-btn ${db.settings.theme==='blue'?'active':''}" onclick="applyTheme('blue');settingsPage()"><div class="theme-swatch" style="background:linear-gradient(135deg,#3b82f6,#60a5fa)"></div>ব্লু</button>
<button class="theme-btn ${db.settings.theme==='green'?'active':''}" onclick="applyTheme('green');settingsPage()"><div class="theme-swatch" style="background:linear-gradient(135deg,#16a56b,#35c98a)"></div>সবুজ</button>
<button class="theme-btn ${db.settings.theme==='rose'?'active':''}" onclick="applyTheme('rose');settingsPage()"><div class="theme-swatch" style="background:linear-gradient(135deg,#e85d8b,#f78caf)"></div>রোজ</button>
<button class="theme-btn ${db.settings.theme==='orange'?'active':''}" onclick="applyTheme('orange');settingsPage()"><div class="theme-swatch" style="background:linear-gradient(135deg,#f08a24,#ffb347)"></div>অরেঞ্জ</button>
<button class="theme-btn ${db.settings.theme==='dark'?'active':''}" onclick="applyTheme('dark');settingsPage()"><div class="theme-swatch" style="background:linear-gradient(135deg,#202031,#7c6cff)"></div>ডার্ক</button>
<button class="theme-btn ${db.settings.theme==='sky'?'active':''}" onclick="applyTheme('sky');settingsPage()"><div class="theme-swatch" style="background:linear-gradient(135deg,#0ea5e9,#38bdf8)"></div>আকাশি</button>
<button class="theme-btn ${db.settings.theme==='cream'?'active':''}" onclick="applyTheme('cream');settingsPage()"><div class="theme-swatch" style="background:linear-gradient(135deg,#9a6b22,#f3d08a)"></div>ক্রিম</button>
<button class="theme-btn ${db.settings.theme==='mint'?'active':''}" onclick="applyTheme('mint');settingsPage()"><div class="theme-swatch" style="background:linear-gradient(135deg,#059669,#34d399)"></div>মিন্ট</button></div></div>
<div class="card section"><h3>🖼️ পুরো অ্যাপের Background Theme</h3><div class="sub">একটি থিম বেছে নিলে Home, Dashboard-এর বাইরের Background, হিসাব বক্স ও পণ্য অংশের Background একসাথে বদলাবে।</div><div class="theme-grid" style="margin-top:10px">${[["blueWhite","Blue White","linear-gradient(135deg,#f5f8ff,#2563eb)"],["softPurple","Soft Purple","linear-gradient(135deg,#f7f4ff,#8b5cf6)"],["leaf","পাতার বাগান","radial-gradient(circle at 18% 15%,#b7efc5 0 7%,transparent 8%),radial-gradient(circle at 78% 72%,#73d98b 0 6%,transparent 7%),linear-gradient(135deg,#eaffef,#138a52)"],["sunrise","সূর্যের আভা","radial-gradient(circle at 82% 18%,#ffd86b 0 12%,transparent 28%),radial-gradient(circle at 20% 85%,#ff9b54 0 8%,transparent 26%),linear-gradient(135deg,#fff7c7,#ff8a3d)"],["ocean","Ocean Glow","radial-gradient(circle at 15% 15%,#a7f3ff 0 8%,transparent 28%),radial-gradient(circle at 85% 80%,#38bdf8 0 7%,transparent 25%),linear-gradient(135deg,#e6fbff,#087ea4)"],["auroraGlow","Aurora Glow","radial-gradient(circle at 25% 25%,#b6ffdf 0 8%,transparent 25%),radial-gradient(circle at 80% 20%,#c8a7ff 0 9%,transparent 28%),linear-gradient(135deg,#f1ecff,#5530c8)"],["sunsetGlow","Sunset Glow","radial-gradient(circle at 80% 20%,#ffd06a 0 10%,transparent 28%),linear-gradient(135deg,#fff0d9,#ff4f81)"],["paper","Paper","linear-gradient(135deg,#fffef8,#ece7da)"],["ice","Ice Blue","linear-gradient(135deg,#eef8ff,#0ea5e9)"],["mint","Mint","linear-gradient(135deg,#effcf6,#10b981)"],["rose","Rose","linear-gradient(135deg,#fff4f8,#ec4899)"],["warm","Warm Gold","linear-gradient(135deg,#fff8ef,#f59e0b)"],["midnight","Midnight","linear-gradient(135deg,#080b14,#111827)"],["royal","Royal","linear-gradient(135deg,#eef2ff,#4338ca)"],["sunset","Sunset","linear-gradient(135deg,#fff1ed,#f97316)"],["forest","Forest","linear-gradient(135deg,#eefaf4,#047857)"],["slate","Slate","linear-gradient(135deg,#eef1f5,#475569)"],["lavender","Lavender","linear-gradient(135deg,#f5f1ff,#7c3aed)"]].map(x=>`<button class="theme-btn ${db.settings.appBg===x[0]?'active':''}" onclick="applyAppBackground('${x[0]}');settingsPage()"><div class="theme-swatch" style="background:${x[2]}"></div>${x[1]}</button>`).join("")}</div></div><div class="card section"><h3>✨ Premium ড্যাশবোর্ড ডিজাইন</h3><div class="sub">ছবির মতো গাঢ়, premium gradient card ব্যবহার করুন। প্রতিটি কাজের বাটনের জন্য আলাদা রং বেছে নিতে পারবেন।</div><h4 style="margin:14px 0 8px">🎛️ সব বাটনের থিম</h4><div class="sub">সেভ/যোগ/রিটার্ন/মেনু ও স্লাইড মেনুর বাটনগুলোও একই premium style-এ যাবে।</div><div class="theme-grid button-theme-grid" style="margin-top:10px">${[["neon","Premium Neon","linear-gradient(135deg,#6d28d9,#00c2ff)"],["jewel","Jewel","linear-gradient(135deg,#7f1d1d,#d97706)"],["aurora","Aurora","linear-gradient(135deg,#047857,#0891b2)"],["mono","Midnight","linear-gradient(135deg,#111827,#374151)"]].map(x=>`<button class="theme-btn ${db.settings.buttonTheme===x[0]?"active":""}" onclick="applyButtonTheme('${x[0]}');settingsPage()"><div class="theme-swatch" style="background:${x[2]}"></div>${x[1]}</button>`).join("")}</div><h4 style="margin:14px 0 8px">ড্যাশবোর্ডের পুরো Background</h4><div class="theme-grid">${[["midnight","Midnight","#070a18"],["black","Deep Black","#0b0d12"],["charcoal","Charcoal","#11151c"],["purple","Deep Purple","#17102f"],["blue","Deep Blue","#071a33"],["green","Deep Green","#071f1a"],["wine","Wine","#260914"],["royal","Royal","#0d1233"],["aurora","Aurora","#071b20"]].map(x=>`<button class="theme-btn ${db.settings.dashboardBg===x[0]?"active":""}" onclick="db.settings.dashboardBg='${x[0]}';save();applyDashboardStyle();settingsPage()"><div class="theme-swatch" style="background:${x[2]}"></div>${x[1]}</button>`).join("")}</div><h4 style="margin:16px 0 8px">Card-এর Base Style</h4><div class="theme-grid">${[["gradient","Premium Gradient","linear-gradient(135deg,#11152b,#17122f)"],["black","Obsidian","#0c0f16"],["charcoal","Graphite","#141923"],["navy","Midnight Navy","#0b1730"],["plum","Deep Plum","#21102f"]].map(x=>`<button class="theme-btn ${db.settings.dashboardCardBg===x[0]?"active":""}" onclick="db.settings.dashboardCardBg='${x[0]}';save();applyDashboardStyle();settingsPage()"><div class="theme-swatch" style="background:${x[2]}"></div>${x[1]}</button>`).join("")}</div><h4 style="margin:16px 0 8px">প্রতিটি বাটনের আলাদা Premium Color</h4><div class="sub">নিচের প্রতিটি লাইনে একটি রং নির্বাচন করুন। যেই Card-এ চাপবেন, সেই কাজের Button-এর রং বদলাবে।</div><div class="premium-color-list">${[["income","মোট আয়"],["expense","মোট ব্যয়"],["products","মোট পণ্য"],["parties","মোট পার্টি"],["sales","মোট বিক্রি"],["purchase","মোট ক্রয়"],["dues","মোট বকেয়া"],["debt","মোট দেনা"],["stock","মোট স্টক"],["stockValue","স্টক মূল্য"],["profit","লাভ / ক্ষতি"]].map(([k,label])=>`<div class="premium-color-row"><b>${label}</b><div class="premium-swatches">${[["ruby","Ruby","#ff2d75"],["indigo","Indigo","#3b82ff"],["blue","Electric Blue","#1677ff"],["pink","Hot Pink","#ff1493"],["orange","Orange","#ff8a00"],["teal","Teal","#00d4b8"],["violet","Violet","#8b5cf6"],["emerald","Emerald","#00c98b"],["cyan","Cyan","#00c8ff"],["gold","Gold","#f5b400"],["purple","Purple","#a855f7"],["red","Red","#ef4444"],["magenta","Magenta","#e00078"],["turquoise","Turquoise","#00c9b7"]].map(c=>`<button title="${c[1]}" class="premium-swatch ${db.settings.dashboardCardColors?.[k]===c[0]?"active":""}" style="--sw:${c[2]}" onclick="setDashboardCardColor('${k}','${c[0]}')"></button>`).join("")}</div></div>`).join("")}</div><h4 style="margin:16px 0 8px">Card Border</h4><div class="theme-panel-inline">${[["soft","Soft"],["strong","Strong"],["glow","Premium Glow"]].map(x=>`<button class="theme-chip ${db.settings.dashboardBorder===x[0]?"active":""}" onclick="db.settings.dashboardBorder='${x[0]}';save();applyDashboardStyle();settingsPage()">${x[1]}</button>`).join("")}</div></div><div class="card section"><h3>🎨 ফর্ম / হিসাব বক্সের Background</h3><div class="sub">ক্রয়-বিক্রয়ের নিচের সাদা হিসাব বক্সসহ summary panel-এর রং বদলাতে পারবেন। সাদা রংয়ে লেখা না দেখা গেলে গাঢ় রং নির্বাচন করুন।</div><div class="theme-grid" style="margin-top:10px">${[["auto","থিম অনুযায়ী","var(--card)"],["obsidian","Obsidian","#0b0d12"],["navy","Deep Navy","#0b1730"],["plum","Deep Plum","#21102f"],["wine","Wine","#300d1b"],["emerald","Emerald","#073b2f"],["royal","Royal Blue","#101d4a"],["gold","Dark Gold","#3a2605"]].map(x=>`<button class="theme-btn ${db.settings.panelBg===x[0]?'active':''}" onclick="applyPanelBg('${x[0]}');settingsPage()"><div class="theme-swatch" style="background:${x[2]}"></div>${x[1]}</button>`).join('')}</div></div><div class="card section"><h3>🧱 পণ্য তালিকার Background</h3><div class="sub">এটি পুরো অ্যাপের Background নয়—পণ্য/স্টক অংশের যে বড় কালো/কার্ড Background দেখেন, সেটি পরিবর্তন করবে।</div><div class="theme-grid" style="margin-top:10px">${[["auto","থিম অনুযায়ী","var(--card)"],["white","সাদা","#fff"],["gray","হালকা ধূসর","#f1f2f4"],["black","কালো","#111214"],["purple","গাঢ় পার্পল","#241d3d"],["blue","গাঢ় নীল","#10243a"],["green","গাঢ় সবুজ","#102d24"]].map(x=>`<button class="theme-btn ${db.settings.productBg===x[0]?'active':''}" onclick="applyProductBg('${x[0]}');settingsPage()"><div class="theme-swatch" style="background:${x[2]}"></div>${x[1]}</button>`).join('')}</div></div><div class="card section"><h3>🧩 Dashboard Box সাজানো</h3><div class="sub">Home-এর বক্সগুলো উপরে/নিচে/বামে/ডানে সরাতে “বক্স সাজান” চাপুন। পরিবর্তন স্বয়ংক্রিয়ভাবে সেভ হবে।</div><button class="btn" style="margin-top:10px" onclick="toggleDashboardArrange()">⚙️ Dashboard বক্স সাজান</button></div><div class="card section"><h3>🏪 দোকানের লোগো</h3><img id="logoPreview" class="logo-preview" src="${db.settings.logo||(!db.settings.logoRemoved?'branding/business360_logo.png':'')}" ${db.settings.logo||!db.settings.logoRemoved?'':'style="display:none"'}><input id="logoFile" type="file" accept="image/*" class="input" onchange="saveLogoFile(this.files[0])"><div class="sub" style="margin-top:8px">লোগো দিলে উপরের দোকানের নামের পাশে দেখা যাবে। সর্বোচ্চ ৪ MB।</div><button class="btn danger sm" style="margin-top:10px" onclick="db.settings.logo='';db.settings.logoRemoved=true;save();applyLogo('');settingsPage()">লোগো সরান</button></div>
<div class="card section"><div class="formrow"><div class="field"><label>দোকানের নাম</label><input id="setShop" class="input" value="${esc(db.settings.shop)}"></div><div class="field"><label>Invoice Prefix</label><input id="setPrefix" class="input" value="${esc(db.settings.invoicePrefix)}"></div></div><div class="formrow"><div class="field"><label>ফোন</label><input id="setPhone" class="input" value="${esc(db.settings.phone)}"></div><div class="field"><label>Low Stock Alert</label><input id="setLow" class="input" type="number" min="0" value="${db.settings.lowStock}"></div></div><div class="field"><label>ঠিকানা</label><textarea id="setAddr" class="textarea">${esc(db.settings.address)}</textarea></div><button class="btn" onclick="saveSettings()">সেভ করুন</button></div>
<div class="card section"><h3>🔐 নিরাপত্তা</h3><div class="sub" style="margin-bottom:10px">বর্তমান অবস্থা: <b>${db.settings.securityMode==='none'?'লক বন্ধ':db.settings.securityMode==='pin'?'PIN Lock চালু':'Pattern Lock চালু'}</b></div><button class="btn" onclick="securityModal()">PIN / Pattern Lock সেটিংস</button></div>
<div class="card section"><h3>💾 Backup / Restore</h3><div class="toolbar"><button class="btn" onclick="downloadBackup()">Backup Download</button><label class="btn secondary">Backup Restore<input id="restoreFile" type="file" accept=".json" hidden onchange="restoreBackup(this.files[0])"></label></div><div class="sub" style="margin-top:8px">লোকাল কপি মোবাইলের browser storage-এ থাকে। Backup ফাইল আলাদা করে Drive-এ রাখুন।</div></div><div class="card section"><h3>🛡️ Safety Backup / ভুল হলে আগের অবস্থায় ফিরুন</h3><div class="sub">পণ্য, স্টক, Customer বা Supplier Delete/Reset করার আগে স্বয়ংক্রিয় Backup নেওয়া হয়। এখান থেকে যেকোনো Backup Restore করতে পারবেন।</div><div class="toolbar" style="margin-top:10px"><button class="btn" onclick="openSafetyBackups()">💾 Backup দেখুন / Restore</button><button class="btn gray" onclick="makeSafetyBackup('ম্যানুয়াল Safety Backup');toast('ম্যানুয়াল Safety Backup নেওয়া হয়েছে')">＋ এখনই Backup</button></div></div><div class="card section reset-card"><h3>♻️ নতুন করে স্টক / হিসাব শুরু</h3><div class="sub">প্রথম অপশনে শুধু সব পণ্যের Stock 0 হবে। দ্বিতীয় অপশনে পুরোনো Sales, Purchase, Expense, Payment ও Due-ও 0 হবে; তবে আপনার Product ও Party-এর নাম থাকবে। প্রতিটি Reset-এর আগে Safety Backup হবে।</div><div class="toolbar" style="margin-top:12px"><button class="btn stock-zero" onclick="if(confirm('সব পণ্যের Stock 0 হবে। Product/Party নাম থাকবে। আগে Safety Backup নেওয়া হবে। চালাবেন?'))resetAllStockOnly()">🧹 সব Stock 0 করুন</button><button class="btn danger-outline" onclick="if(confirm('পুরোনো Sales/Purchase/Expense/Payment/Return এবং Stock সব 0 হবে। Product ও Party নাম থাকবে। আগে Safety Backup নেওয়া হবে। চালাবেন?'))startFreshBusiness()">🔄 নতুন করে শুরু করুন</button></div><div class="toolbar" style="margin-top:10px"><button class="btn danger-outline" onclick="if(confirm('নতুন মালিককে দেওয়ার জন্য সব Product, Customer, Supplier, Sales, Purchase, Expense, Payment, Return ও Stock সম্পূর্ণ খালি হবে। আগে Safety Backup নেওয়া হবে। চালাবেন?'))clearBusinessForNewOwner()">🧹 নতুন মালিককে দেওয়ার জন্য সব ডেটা খালি করুন</button></div></div>
<div class="card section"><h3>☁️ Google Drive Cloud Sync</h3><div class="notice">মোবাইল বদলালেও হিসাব ফিরে পাওয়ার জন্য এটি ব্যবহার করুন। প্রথমবার Google Drive অনুমতি দিলে হিসাবের একটি private app-data backup রাখা হবে। নতুন মোবাইলে একই Client ID দিয়ে Connect করে Restore করা যাবে।</div><div class="field" style="margin-top:12px"><label>Google OAuth Client ID</label><input id="googleClientId" class="input" placeholder="xxxxx.apps.googleusercontent.com" value="${esc(cloudState.clientId||'')}"></div><div class="toolbar"><button class="btn" onclick="saveClientId()">Google Drive Connect</button><button class="btn secondary" onclick="cloudDownload(false)">Drive থেকে Restore</button><button class="btn gray" onclick="cloudUpload(false)">এখনই Backup</button><button class="btn danger" onclick="cloudDisconnect()">Disconnect</button></div><div id="cloudStatus" class="sub" style="margin-top:10px">${cloudState.connected?'Google Drive সংযুক্ত ✓':'Google Drive সংযুক্ত নয়'}</div><div class="sub" style="margin-top:8px">সেভ করার পর ১.৫ সেকেন্ডের মধ্যে Cloud Backup আপডেট হবে (Drive connected ও internet থাকলে)।</div></div>`}
function downloadBackup(){const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify(db,null,2)],{type:'application/json'}));a.download='business360-backup-'+today()+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}
function restoreBackup(f){if(!f)return;const r=new FileReader();r.onload=()=>{try{const x=JSON.parse(r.result);if(!x.products||!x.sales)throw Error();db=migrateData(x);save();applyTheme(db.settings.theme||'purple');applyLogo(db.settings.logo||'');render('dashboard');toast('Backup restore হয়েছে')}catch(_){toast('সঠিক backup file দিন')}};r.readAsText(f)}
function saveSettings(){db.settings.shop=document.getElementById("setShop").value||"আমার দোকান";db.settings.invoicePrefix=document.getElementById("setPrefix").value||"INV";db.settings.phone=document.getElementById("setPhone").value;db.settings.lowStock=num(document.getElementById("setLow").value);db.settings.address=document.getElementById("setAddr").value;save();const brand=document.getElementById("brand");if(brand)brand.textContent=db.settings.shop;toast("দোকানের তথ্য সেভ হয়েছে");render("settings")}
function resetAllStockOnly(){
  if(!db.products.length){toast("কোনো পণ্য নেই");return}
  makeSafetyBackup("সব স্টক 0 করার আগের অবস্থা");
  db.products.forEach(p=>{if(num(p.stock)!==0){addMove(p.id,-num(p.stock),"ADJUST","RESET","সব স্টক 0 করা হয়েছে");p.stock=0}});
  save();render("dashboard");toast("সব পণ্যের স্টক 0 করা হয়েছে");
}
function startFreshBusiness(){
  makeSafetyBackup("নতুন করে ব্যবসা শুরু করার আগের অবস্থা");
  db.products.forEach(p=>p.stock=0);
  db.customers.forEach(p=>p.openingDue=0);db.suppliers.forEach(p=>p.openingDue=0);
  db.sales=[];db.purchases=[];db.expenses=[];db.payments=[];db.returns=[];db.stockMoves=[];
  db.counters={sale:1001,purchase:2001,return:3001};saleCart=[];purchaseCart=[];
  save();render("dashboard");toast("নতুন করে শুরু হয়েছে — পণ্য ও Party নাম রাখা হয়েছে, সব হিসাব/স্টক 0");
}
function clearBusinessForNewOwner(){
  makeSafetyBackup("নতুন মালিককে দেওয়ার আগে সম্পূর্ণ ব্যবসা খালি করার Backup");
  db.products=[];db.customers=[];db.suppliers=[];db.sales=[];db.purchases=[];db.expenses=[];db.payments=[];db.returns=[];db.stockMoves=[];
  db.counters={sale:1001,purchase:2001,return:3001};saleCart=[];purchaseCart=[];
  save();render("dashboard");toast("সব ব্যবসায়িক ডেটা খালি হয়েছে — নতুন মালিকের জন্য প্রস্তুত");
}
function resetData(){if(confirm("সব বিক্রয়, পণ্য, Party ও হিসাব মুছে যাবে। আগে Backup নিয়েছেন?")){makeSafetyBackup("পুরোনো Reset Data");localStorage.removeItem(KEY);db=clone(initial);saleCart=[];purchaseCart=[];location.reload()}}

function aboutPage(){
const logo=db.settings.logo||(!db.settings.logoRemoved?'branding/business360_logo.png':'');
document.getElementById('about').innerHTML=`<div class="about-wrap">
<div class="about-hero"><div class="about-brand">${logo?`<img src="${logo}" alt="Business360 logo">`:''}<div><div class="about-kicker">Meet the Developer</div><div class="about-name">Md Sahadul Hoque Rumu</div><div class="about-role">Founder & Developer · Business360</div><div class="sub" style="margin-top:6px">WhatsApp: 01795934394 · Email: shrumu7@gmail.com</div></div></div>
<div class="about-quote">“Technology becomes truly meaningful when it solves a real problem and makes everyday life easier.”</div></div>
<div class="about-card"><h3>👨‍💻 About the Developer</h3><p>An engineer, educator, entrepreneur, and technology enthusiast passionate about transforming practical ideas into meaningful digital solutions.</p><p style="margin-top:10px">With a background in <b>Electrical & Electronics Engineering</b>, a career in education, and hands-on experience in business, I have always been driven by curiosity, innovation, and real-world problem solving.</p><p style="margin-top:10px">My journey in technology also includes competitive robotics, where two robots developed by me achieved <b>Champion and Runner-up</b> positions in a Line Follower Robot competition.</p></div>
<div class="about-card"><h3>🚀 Why Business360?</h3><p>Business360 was born from real-world business experience. The goal is simple: make everyday business management easier, clearer, and more accessible for small and growing businesses.</p></div>
<div class="about-card"><h3>✨ What you can do with Business360</h3><div class="about-list"><div class="about-item">📦<div><b>Products & Stock</b><span>Manage products, stock, purchase price, sale price and inventory value.</span></div></div><div class="about-item">🛒<div><b>Sales & Purchases</b><span>Create sales and purchase records, invoices, returns and multiple-item transactions.</span></div></div><div class="about-item">👥<div><b>Customers & Suppliers</b><span>Keep party information, transaction history and due accounts organized.</span></div></div><div class="about-item">📊<div><b>Reports & Profit</b><span>Track income, expenses, sales, purchases, stock value and profit or loss.</span></div></div><div class="about-item">🔐<div><b>Backup & Security</b><span>Use backup, restore, safety backup and security features to protect important business data.</span></div></div></div></div>
<div class="about-card"><h3>🔮 Our Vision</h3><p>Business360 is more than an accounting app. It is a step toward a complete digital business management platform for small and growing businesses.</p><div class="about-list"><div class="about-item">☁️<div><b>Cloud & Sync</b><span>More reliable cloud backup and device-to-device continuity.</span></div></div><div class="about-item">📈<div><b>Smarter Analytics</b><span>More powerful reports and business insights.</span></div></div><div class="about-item">⚡<div><b>More Automation</b><span>Faster workflows, barcode improvements, invoicing and smarter tools.</span></div></div><div class="about-item">🛡️<div><b>Stronger Protection</b><span>Improved security and licensing for a dependable commercial platform.</span></div></div></div></div>
<div class="about-footer"><div class="about-badge">Made in Bangladesh · Built with Purpose</div><br><b>Business360</b> — Your Business Partner<br><span>Developed with ❤️ by Md Sahadul Hoque Rumu</span></div>
</div>`}

function render(id){
 try{
  if(id==="dashboard")dashboard();if(id==="sale")salePage();if(id==="transactions")transactionsPage();if(id==="purchase")purchasePage();if(id==="products")productsPage();if(id==="parties")partiesPage();if(id==="dues")duesPage();if(id==="expenses")expensesPage();if(id==="returns")returnsPage();if(id==="reports")reportsPage();if(id==="settings")settingsPage();if(id==="about")aboutPage();
  document.getElementById("brand").textContent=db.settings.shop||"Business360";applyLogo(db.settings.logoRemoved?"":(db.settings.logo||""));applyTheme(db.settings.theme||"purple",true);applyAppBackground(db.settings.appBg||"blueWhite",true);applyProductBg(db.settings.productBg||"auto",true);applyDashboardStyle();
 }catch(e){const el=document.getElementById(id);if(el)el.innerHTML=`<div class="card"><h2>এই পেজটি দেখাতে সমস্যা হয়েছে</h2><p>${esc(e.message||e)}</p><button class="btn" onclick="render('${id}')">আবার চেষ্টা করুন</button></div>`;console.error(e)}
}
let deferredInstallPrompt=null;
window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();deferredInstallPrompt=e;const b=document.getElementById('installBtn');if(b)b.style.display='block';});
window.addEventListener('appinstalled',()=>{deferredInstallPrompt=null;const b=document.getElementById('installBtn');if(b)b.style.display='none';toast('হোম স্ক্রিনে Business360 যোগ হয়েছে');});
async function installApp(){if(!deferredInstallPrompt){toast('Chrome-এর মেনু থেকে “Add to Home screen / Install app” ব্যবহার করুন। HTTPS সাইটে এই অপশন পাওয়া যাবে।');return}deferredInstallPrompt.prompt();await deferredInstallPrompt.userChoice;deferredInstallPrompt=null;document.getElementById('installBtn').style.display='none';}
const installBtn=document.getElementById('installBtn'); if(installBtn) installBtn.onclick=installApp;

async function boot(){
  try{
   await initDataStore();
   render("dashboard");
   if(cloudState.clientId) cloudStatus("Google Drive সংযুক্ত নয় — Connect চাপুন");
   lockOverlay();
  }catch(e){
   document.getElementById("dashboard").innerHTML=`<div class="card"><h2>অ্যাপ চালু হতে সমস্যা হয়েছে</h2><p>${esc(e.message||e)}</p><button class="btn" onclick="location.reload()">আবার চেষ্টা করুন</button></div>`;
  }
}
window.addEventListener("error",e=>{const msg=e.message||"Unknown error";console.error(e);toast("ত্রুটি: "+msg)});
boot();
if(location.protocol!=="file:" && "serviceWorker" in navigator){window.addEventListener("load",()=>navigator.serviceWorker.register("sw.js?v=51").then(r=>{if(r.waiting)r.waiting.postMessage({type:'SKIP_WAITING'});}).catch(()=>{}));}

